'use strict';
// Админ-зона: список сотрудников (вкладка «Сотрудники»), удаление с передачей лидов, вкладка «Активность клиентов». Вынесено из app.js (план CODE_REVIEW п. 10.9).
/* global $, APP_STATUS_LABELS, Loading, Modal, Net, Store, Toast, esc, fmtDateTime, fmtMoney, fmtMoneyKop, plural */
/* exported activityShiftYear, confirmDeleteUser, loadApps, openDeleteUser, setActivityUser, setAppsQuery, setAppsUser, usersTableBusy */

let _usersCache = [];

async function loadUsers() {
  const res = await Net.req('get_users'); if (!res || !res.success) return;
  _usersCache = res.users || [];
  const tbody = $('#users-tbody'); tbody.innerHTML = '';
  const currId = Store.state.user.id;
  // Empty state (#3): если в системе только текущий пользователь — показываем подсказку
  if (_usersCache.length <= 1) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td colspan="7" class="cell-muted">Добавьте сотрудников, чтобы распределять лиды и вести совместную работу.</td>';
    tbody.appendChild(tr);
    if (_usersCache.length === 0) return;
  }
  _usersCache.forEach(u => {
    const tr = document.createElement('tr');
    const role = u.role === 'admin' ? 'admin' : 'user';
    tr.innerHTML = `
      <td>${u.id}</td>
      <td><input class="user-input" id="uname-${u.id}" value="${esc(u.name)}"></td>
      <td><input class="user-input" id="uemail-${u.id}" value="${esc(u.email)}"></td>
      <td><select class="user-input" id="urole-${u.id}"><option value="user"${role==='user'?' selected':''}>Сотрудник</option><option value="admin"${role==='admin'?' selected':''}>Админ</option></select></td>
      <td class="td-leads">${Number(u.leads) || 0}</td>
      <td><input class="user-input" id="upass-${u.id}" type="password" autocomplete="new-password" placeholder="Пусто = не менять"></td>
      <td>
        <button class="btn btn-primary btn-sm" data-action="save-user" data-id="${u.id}">💾</button>
        ${u.id !== currId ? `<button class="btn btn-danger btn-sm" data-action="delete-user" data-id="${u.id}">🗑️</button>` : ''}
      </td>`;
    // Отмечаем ручной ввод пароля: событие input от автозаполнения браузера isTrusted, но без
    // нажатий клавиш; проверяем keydown/paste в самом поле.
    const passEl = tr.querySelector(`#upass-${u.id}`);
    if (passEl) {
      const mark = () => { passEl.dataset.typed = '1'; };
      passEl.addEventListener('keydown', mark);
      passEl.addEventListener('paste', mark);
      passEl.addEventListener('input', () => { if (!passEl.value) delete passEl.dataset.typed; });
    }
    tbody.appendChild(tr);
  });
}

// Модалка удаления сотрудника: показывает, сколько у него лидов, и предлагает передать их
// другому сотруднику (по умолчанию) либо удалить безвозвратно вместе с логами и файлами.
let _deleteUserId = null;

function openDeleteUser(id) {
  const u = _usersCache.find(x => x.id === id);
  if (!u) return;
  _deleteUserId = id;
  const n = Number(u.leads) || 0;
  const sel = $('#du-transfer');
  const others = _usersCache.filter(x => x.id !== id);
  const me = Store.state.user.id;
  sel.innerHTML = others.map(o => `<option value="${o.id}"${o.id === me ? ' selected' : ''}>Передать: ${esc(o.name)}${o.id === me ? ' (мне)' : ''}</option>`).join('')
    + '<option value="0">Удалить безвозвратно (лиды, лог, файлы, заявки)</option>';
  $('#du-message').textContent = n
    ? `${u.name}: ${n} ${plural(n, 'лид', 'лида', 'лидов')} на доске.`
    : `${u.name}: лидов на доске нет.`;
  $('#du-transfer-field').classList.toggle('hidden', n === 0);
  const hint = $('#du-hint');
  const upd = () => {
    const del = sel.value === '0';
    hint.textContent = del ? 'Отменить будет нельзя.' : 'Этап сохранится, если он есть у получателя; в лог каждого лида добавится запись о передаче.';
    hint.classList.toggle('danger', del);
  };
  sel.onchange = upd; upd();
  Modal.open('modal-delete-user');
}

async function confirmDeleteUser() {
  const id = _deleteUserId; if (!id) return;
  const u = _usersCache.find(x => x.id === id);
  const n = Number(u?.leads) || 0;
  const transferTo = n ? Number($('#du-transfer').value) || 0 : 0;
  const res = await Net.req('delete_user', { id, transferTo });
  if (!res?.success) { Toast.error(res?.error || 'Ошибка'); return; }
  Modal.closeAll(); _deleteUserId = null;
  const moved = Number(res.transferred) || 0;
  Toast.success(moved ? `Удалён, передано ${moved} ${plural(moved, 'лид', 'лида', 'лидов')}` : 'Удалён');
  loadUsers(); Store.load(true);
}

function usersTableBusy() {
  const tbody = $('#users-tbody'); if (!tbody) return false;
  if (tbody.contains(document.activeElement)) return true;
  return [...tbody.querySelectorAll('input, select')].some(i => {
    if (i.type === 'password') return !!i.value;
    return i.value !== i.defaultValue;
  });
}

// === АКТИВНОСТЬ КЛИЕНТОВ ===
let _activityYear = new Date().getFullYear();

const _activityCache = {};

let _activityUserId = null; // локальный для вкладки «Активность», не влияет на «Лиды»
let _activityUserManual = false; // true — сотрудник выбран в селекте вручную, viewUserId не наследуем
// Обёртки для обработчиков в app.js (кросс-файловая запись в let ломает ESLint и прячет зависимость):
// листание года стрелками и выбор сотрудника в селекте вкладки.
function activityShiftYear(delta) { return loadActivity(_activityYear + delta); }
function setActivityUser(id) { _activityUserId = (!id || id === Store.state.user?.id) ? null : id; _activityUserManual = true; }

async function loadActivity(year) {
  if (year != null) _activityYear = year;
  // Ревью, п. 2.2 (вариант «а»): при просмотре чужой доски вкладка по умолчанию показывает
  // её владельца, а не себя; ручной выбор в селекте переопределяет и запоминается.
  if (!_activityUserManual && Store.viewUserId) _activityUserId = Store.viewUserId;
  Loading.show();
  try {
    // Через Net.req: раньше здесь был голый fetch — need_login не разлогинивал,
    // ошибки терялись молча (см. код-ревью, п. 2.9)
    const res = await Net.req('get_activity', { year: _activityYear, as: _activityUserId || 0 });
    if (!res || !res.success) { if (res?.error) Toast.error(res.error); return; }
    _activityYear = res.year || _activityYear;
    // Кэш ограничен: старые годы/сотрудники вытесняются (раньше рос без предела всю сессию)
    const keys = Object.keys(_activityCache);
    if (keys.length > 24) delete _activityCache[keys[0]];
    _activityCache[_activityYear + ':' + (_activityUserId || 'me')] = res.clients || [];
    renderActivity();
  } finally {
    Loading.hide();
  }
}

function renderActivity() {
  const yearEl = $('#activity-year');
  if (yearEl) yearEl.textContent = String(_activityYear);
  renderEmployeeSelect($('#activity-employee'), _activityUserId || Store.state.user?.id);
  const tbody = $('#activity-tbody');
  if (!tbody) return;
  const cacheKey = _activityYear + ':' + (_activityUserId || 'me');
  let clients = _activityCache[cacheKey] || [];
  // Сортировка: сначала клиенты с поездками (по убыванию итого), потом без поездок
  clients = clients.slice().sort((a, b) => {
    const totalA = Object.values(a.months).reduce((s, v) => s + v, 0);
    const totalB = Object.values(b.months).reduce((s, v) => s + v, 0);
    return totalB - totalA;
  });
  tbody.innerHTML = '';
  if (!clients.length) {
    tbody.innerHTML = '<tr><td colspan="14" class="cell-muted">Нет поездок за этот год</td></tr>';
    return;
  }
  const frag = document.createDocumentFragment();
  clients.forEach(c => {
    const tr = document.createElement('tr');
    let totalTrips = 0;
    let monthCells = '';
    for (let m = 1; m <= 12; m++) {
      const count = c.months[m] || 0;
      totalTrips += count;
      if (count > 0) {
        monthCells += `<td class="activity-cell active" title="${count} ${plural(count, 'поездка', 'поездки', 'поездок')}" >${count}</td>`;
      } else {
        monthCells += '<td class="activity-cell"></td>';
      }
    }
    tr.innerHTML = `<td class="activity-client"><span class="name-link" data-action="open-activity-client" data-inn="${esc(c.inn)}">${esc(c.title)}</span><div class="activity-inn">${esc(c.inn)}</div></td>${monthCells}<td class="activity-total">${totalTrips}</td>`;
    frag.appendChild(tr);
  });
  tbody.appendChild(frag);
}

/* === ВКЛАДКА «ЗАЯВКИ» (реестр заявок менеджера) === */
// Как «Активность»: выбор сотрудника локален для вкладки и не влияет на «Лиды».
let _appsUserId = null;
let _appsUserManual = false; // true — сотрудник выбран в селекте вручную, viewUserId не наследуем
let _appsQuery = '';
let _appsCache = null; // последний ответ get_apps (список + итоги)
let _appsGen = 0; // защита от гонки ответов при быстром наборе в поиске (как _searchGen)

function setAppsUser(id) { _appsUserId = (!id || id === Store.state.user?.id) ? null : id; _appsUserManual = true; }
function setAppsQuery(q) { _appsQuery = q; }

// Селект сотрудника в шапке вкладки (только для админов) — общий для «Активности» и «Заявок»
function renderEmployeeSelect(sel, curId) {
  if (!sel) return;
  const isAdmin = Store.state.user?.role === 'admin';
  sel.style.display = isAdmin ? '' : 'none';
  if (!isAdmin) return;
  sel.innerHTML = (Store.state.colleagues || []).map(u =>
    `<option value="${esc(u.id)}">${esc(u.name)}</option>`
  ).join('');
  sel.value = String(curId);
}

async function loadApps() {
  const gen = ++_appsGen;
  // Как в loadActivity (ревью, п. 2.2, вариант «а»): чужая доска — показываем её владельца.
  if (!_appsUserManual && Store.viewUserId) _appsUserId = Store.viewUserId;
  Loading.show();
  try {
    const res = await Net.req('get_apps', { q: _appsQuery, as: _appsUserId || 0 });
    if (gen !== _appsGen) return; // пришёл ответ на устаревший запрос — новее уже в пути
    if (!res || !res.success) { if (res?.error) Toast.error(res.error); return; }
    _appsCache = res;
    renderApps();
  } finally {
    Loading.hide();
  }
}

// Название организации в колонке «Компания» реестра заявок: одно на все строки
// (как в Odoo). Меняется одной строкой.
const APPS_COMPANY = 'ООО «Детроид»';

// Инициалы + детерминированный цвет аватара продавца (8 классов apps-av0..7).
function sellerAvatar(name) {
  const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
  const initials = parts.slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  let h = 0;
  for (const ch of String(name || '')) h = (h + ch.codePointAt(0)) % 8;
  return `<span class="apps-avatar apps-av${h}" aria-hidden="true">${esc(initials)}</span>`;
}

function renderApps() {
  renderEmployeeSelect($('#apps-employee'), _appsUserId || Store.state.user?.id);
  const res = _appsCache;
  const summary = $('#apps-summary');
  if (summary) {
    if (res && res.total > 0) {
      const parts = [`${res.total} ${plural(res.total, 'заявка', 'заявки', 'заявок')}`];
      if (res.sumRate) parts.push(`Ставки: ${fmtMoney(res.sumRate)} ₽`);
      if (res.sumMargin) parts.push(`Маржа: ${fmtMoney(res.sumMargin)} ₽`);
      // Список ограничен на сервере (LIMIT 500) — честно говорим, что показана не вся выборка
      if ((res.apps || []).length < res.total) parts.push(`показаны первые ${res.apps.length}`);
      summary.textContent = parts.join(' · ');
    } else {
      summary.textContent = '';
    }
  }
  const tbody = $('#apps-tbody');
  if (!tbody) return;
  const apps = res?.apps || [];
  if (!apps.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="cell-muted">${_appsQuery ? 'Ничего не найдено' : 'Пока нет заявок'}</td></tr>`;
    return;
  }
  tbody.innerHTML = '';
  const frag = document.createDocumentFragment();
  apps.forEach(a => {
    const tr = document.createElement('tr');
    // Без номера — «Открыть»: иначе карточку заявки из реестра не открыть в 1 клик (ревью §26, F1).
    const numCell = a.number
      ? `<span class="name-link" data-action="open-app" data-id="${esc(a.id)}" data-leadid="${esc(a.leadId)}">${esc(a.number)}</span>`
      : `<span class="name-link" data-action="open-app" data-id="${esc(a.id)}" data-leadid="${esc(a.leadId)}">Открыть</span>`;
    const clientCell = `<span class="name-link" data-action="open-app-lead" data-id="${esc(a.leadId)}">${esc(a.leadTitle || '—')}${a.leadInn ? ` - ${esc(a.leadInn)}` : ''}</span>`;
    const sti = (a.status >= 0 && a.status <= 2) ? a.status : 0;
    const statusCell = `<span class="app-status st${sti}">${esc(APP_STATUS_LABELS[sti])}</span>`;
    const marginCell = a.margin ? esc(fmtMoneyKop(a.margin)) : '<span class="apps-dim">—</span>';
    const totalCell = a.rate ? `${esc(fmtMoneyKop(a.rate))} руб` : '<span class="apps-dim">—</span>';
    tr.innerHTML = `<td class="apps-num">${numCell}</td>`
      + `<td class="apps-date">${esc(fmtDateTime(a.createdAt))}</td>`
      + `<td class="apps-company">${esc(APPS_COMPANY)}</td>`
      + `<td><span class="apps-seller">${sellerAvatar(a.sellerName)}${esc(a.sellerName || '—')}</span></td>`
      + `<td>${clientCell}</td>`
      + `<td>${statusCell}</td>`
      + `<td class="apps-money">${marginCell}</td>`
      + `<td class="apps-money apps-total">${totalCell}</td>`;
    frag.appendChild(tr);
  });
  tbody.appendChild(frag);
}
