<?php
declare(strict_types=1);

/*
 * Слой данных CRM: подключение к MySQL (crm_pdo) и SQL-хелперы
 * (crm_*_by_id, crm_*_list, crm_touch_*, crm_purge_*, поиск, пароли).
 * Подключается из api.php после config.php; сам подключает остальные слои
 * (порядок require в api.php и tests/ не менялся):
 *   http.php       — out/ok/err/now_ms/crm_log_fail + CrmError (TODO #20 — выполнено)
 *   security.php   — IP/прокси, лимиты входа, валидация загрузок (TODO #18 — выполнено)
 *   files.php      — вложения uploads/, выдача файлов, уборка (TODO #18 — выполнено)
 *   migrations.php — crm_boot и миграции схемы (TODO #18 — выполнено)
 * Слой данных не завершает HTTP-запрос сам: crm_pdo() и crm_view_uid() бросают CrmError,
 * который api.php превращает в JSON-ответ. Поэтому db.php пригоден в CLI (cron-бэкапы,
 * CLI-миграции): require 'config.php'; require 'db.php'; crm_pdo().
 * Функции между файлами резолвятся в рантайме — взаимные вызовы (migrations → crm_password_hash
 * из db.php) безопасны, т.к. к моменту исполнения все require_once уже отработали.
 */

require_once __DIR__ . '/http.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/files.php';
require_once __DIR__ . '/migrations.php';

/** @return list<array{0:string,1:int}> */
function crm_mysql_targets(string $host, int $port, bool $allowFallback = false): array {
    $host = trim($host);
    if (preg_match('/^([^:;]+)[:;](?:port=)?(\d+)$/', $host, $m)) {
        $host = $m[1];
        $port = (int) $m[2];
    }
    $out = [];
    $add = static function (string $h, int $p) use (&$out): void {
        $key = $h . ':' . $p;
        foreach ($out as $row) {
            if ($row[0] . ':' . $row[1] === $key) return;
        }
        $out[] = [$h, $p];
    };
    $add($host, $port);
    // Фолбэк на SpaceWeb MySQL 8 (127.0.0.1:3308) — только при явном включении.
    // Без этого флага молчаливое подключение к другому MySQL на том же сервере — риск утечки данных.
    if ($allowFallback) {
        $add('127.0.0.1', 3308);
        $add('localhost', 3308);
    }
    return $out;
}

function crm_mysql_connect_hint(PDOException $e): string {
    $msg = $e->getMessage();
    if (stripos($msg, 'could not find driver') !== false) {
        return 'На хостинге нет PHP-расширения pdo_mysql. В панели SpaceWeb включите PHP 8.1+ с MySQL.';
    }
    return 'Не удалось подключиться к базе. Проверьте CRM_DB_HOST, порт, имя, логин и пароль в config.php.';
}

/** @throws CrmError при отсутствии пароля/расширения или недоступности MySQL (TODO #20) */
function crm_pdo(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    // CrmError вместо err() (TODO #20): db.php не завершает HTTP-запрос сам —
    // api.php ловит CrmError и отвечает JSON; в CLI исключение видно как обычная ошибка.
    if (!defined('CRM_DB_PASS') || CRM_DB_PASS === '' || CRM_DB_PASS === 'CHANGE_ME' || CRM_DB_PASS === 'ВПИШИТЕ_ПАРОЛЬ') {
        throw new CrmError('В config.php не задан пароль базы (CRM_DB_PASS). Это не пароль от панели SpaceWeb, а пароль MySQL.');
    }
    if (!extension_loaded('pdo_mysql')) {
        throw new CrmError('На хостинге нет расширения PHP pdo_mysql. Включите PHP 8.1+ с MySQL в панели сайта.');
    }
    $opts = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        // rowCount() = число строк, ПОДОШЕДШИХ под WHERE, а не фактически изменённых.
        // Оптимистическая блокировка (`UPDATE ... WHERE updated_at = ?` → rowCount() === 0 значит
        // «карточку изменили в другом месте») иначе даёт ложный конфликт, если запись совпала по
        // условию, но новые значения оказались равны старым.
        PDO::MYSQL_ATTR_FOUND_ROWS => true,
    ];
    $port = defined('CRM_DB_PORT') ? (int) CRM_DB_PORT : 0;
    // Фолбэк на 127.0.0.1:3308 / localhost:3308 — только если явно включён в config.php
    // (CRM_DB_FALLBACK=1). Без этого флага подключение идёт строго к сконфигурированному хосту:
    // раньше молчаливый фолбэк мог увести подключение в чужой MySQL на том же сервере.
    $allowFallback = defined('CRM_DB_FALLBACK') && CRM_DB_FALLBACK;
    $targets = crm_mysql_targets(CRM_DB_HOST, $port, $allowFallback);
    $last = null;
    $connectedTo = null;
    foreach ($targets as [$host, $p]) {
        try {
            $dsn = 'mysql:host=' . $host . ($p ? ';port=' . $p : '') . ';dbname=' . CRM_DB_NAME . ';charset=' . CRM_DB_CHARSET;
            $pdo = new PDO($dsn, CRM_DB_USER, CRM_DB_PASS, $opts);
            $connectedTo = $host . ':' . $p;
            break;
        } catch (PDOException $e) {
            $last = $e;
            $pdo = null;
        }
    }
    if (!$pdo instanceof PDO) {
        throw new CrmError(crm_mysql_connect_hint($last ?? new PDOException('unknown')));
    }
    // Если подключились не к сконфигурированному хосту — логируем (помогает найти проблемы конфигурации)
    $configured = trim(CRM_DB_HOST) . ':' . ($port ?: 3306);
    if ($connectedTo !== null && $connectedTo !== $configured) {
        error_log('CRM: подключились к ' . $connectedTo . ' вместо сконфигурированного ' . $configured);
    }
    crm_boot($pdo);
    return $pdo;
}

/** Минимальная длина запроса (символов названия или цифр ИНН), при которой ищем пересечения с чужими лидами. */
const CRM_SEARCH_MIN_CHARS = 4;

function crm_meta_get(PDO $pdo, string $k): string {
    try {
        $st = $pdo->prepare('SELECT v FROM crm_meta WHERE k = ?');
        $st->execute([$k]);
        $v = $st->fetchColumn();
        return $v === false ? '0' : (string) $v;
    } catch (PDOException $e) {
        return '0';
    }
}

function crm_meta_bump(PDO $pdo, string $k): void {
    // 'tags_<uid>' — счётчик изменений тегов сотрудника (v17): любое изменение
    // справочника или привязок меняет hash доски в get_data → клиенты перечитывают.
    if ($k !== 'users' && !preg_match('/^tags_\d{1,10}$/', $k)) return;
    try {
        $pdo->prepare('INSERT INTO crm_meta (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = CAST(v AS UNSIGNED) + 1')
            ->execute([$k, '1']);
    } catch (PDOException $e) { /* ok */ }
}

/**
 * Записать событие в аудит-лог. Никогда не роняет основной запрос: аудит — вторичен.
 * Заодно раз в ~200 записей чистит события старше года.
 */
function crm_audit(PDO $pdo, array $actor, string $action, string $target = '', string $details = ''): void {
    try {
        $pdo->prepare('INSERT INTO crm_audit (actor_id, actor_name, action, target, details, ip, created_at) VALUES (?,?,?,?,?,?,?)')
            ->execute([
                (int) ($actor['id'] ?? 0),
                mb_substr((string) ($actor['name'] ?? ''), 0, 80),
                mb_substr($action, 0, 40),
                mb_substr($target, 0, 200),
                mb_substr($details, 0, 500),
                crm_client_ip(),
                now_ms(),
            ]);
        if (random_int(1, 200) === 1) {
            $pdo->prepare('DELETE FROM crm_audit WHERE created_at < ?')->execute([now_ms() - 365 * 86400 * 1000]);
        }
    } catch (Throwable $e) { crm_log_fail('audit', $e); }
}

/**
 * Проверка ссылочной целостности: дополнительная диагностика поверх FOREIGN KEY (v15).
 * Находит orphan-записи там, где FK нет (привязки тегов, v17) или где FK не встал
 * на хостинге (v15 это молча переживает). Возвращает список: [таблица, id, описание].
 * Вызывается из ?action=integrity_check (только для админа) или из cron-скрипта.
 */
function crm_integrity_check(PDO $pdo): array {
    $issues = [];
    // Комментарии без лида
    $st = $pdo->query('SELECT c.id FROM crm_comments c LEFT JOIN crm_leads l ON l.id = c.lead_id WHERE l.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_comments', $id, 'комментарий без лида'];
    }
    // Комментарии перевозчиков без перевозчика
    $st = $pdo->query('SELECT c.id FROM crm_carrier_comments c LEFT JOIN crm_carriers k ON k.id = c.carrier_id WHERE k.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_carrier_comments', $id, 'комментарий без перевозчика'];
    }
    // Вложения без комментария
    $st = $pdo->query('SELECT a.id FROM crm_attachments a LEFT JOIN crm_comments c ON c.id = a.comment_id WHERE c.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_attachments', $id, 'вложение без комментария'];
    }
    $st = $pdo->query('SELECT a.id FROM crm_carrier_attachments a LEFT JOIN crm_carrier_comments c ON c.id = a.comment_id WHERE c.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_carrier_attachments', $id, 'вложение без комментария перевозчика'];
    }
    // Комментарии заявок без заявки и их вложения без комментария (v20)
    $st = $pdo->query('SELECT c.id FROM crm_app_comments c LEFT JOIN crm_lead_apps a ON a.id = c.app_id WHERE a.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_app_comments', $id, 'комментарий заявки без заявки'];
    }
    $st = $pdo->query('SELECT a.id FROM crm_app_attachments a LEFT JOIN crm_app_comments c ON c.id = a.comment_id WHERE c.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_app_attachments', $id, 'вложение без комментария заявки'];
    }
    // Статус заявки вне справочника (ручная правка БД мимо API)
    $st = $pdo->query('SELECT a.id FROM crm_lead_apps a WHERE a.status NOT IN (0,1,2) LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_lead_apps', $id, 'статус заявки вне 0/1/2'];
    }
    // Заявки без лида
    try {
        $st = $pdo->query('SELECT a.id FROM crm_lead_apps a LEFT JOIN crm_leads l ON l.id = a.lead_id WHERE l.id IS NULL LIMIT 100');
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $issues[] = ['crm_lead_apps', $id, 'заявка без лида'];
        }
    } catch (PDOException $e) { /* v8 table may not exist */ }
    // Привязки тегов без лида или без тега (v17)
    try {
        $st = $pdo->query('SELECT CONCAT(lt.lead_id, \'/\', lt.tag_id) FROM crm_lead_tags lt LEFT JOIN crm_leads l ON l.id = lt.lead_id WHERE l.id IS NULL LIMIT 100');
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $issues[] = ['crm_lead_tags', $id, 'привязка тега без лида'];
        }
        $st = $pdo->query('SELECT CONCAT(lt.lead_id, \'/\', lt.tag_id) FROM crm_lead_tags lt LEFT JOIN crm_tags t ON t.id = lt.tag_id WHERE t.id IS NULL LIMIT 100');
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
            $issues[] = ['crm_lead_tags', $id, 'привязка на несуществующий тег'];
        }
    } catch (PDOException $e) { /* до миграции v17 */ }
    // Перевозчики без направления
    $st = $pdo->query('SELECT c.id FROM crm_carriers c LEFT JOIN crm_directions d ON d.id = c.direction_id WHERE d.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_carriers', $id, 'перевозчик без направления'];
    }
    // Лиды без владельца (user_id не в crm_users)
    $st = $pdo->query('SELECT l.id FROM crm_leads l LEFT JOIN crm_users u ON u.id = l.user_id WHERE u.id IS NULL LIMIT 100');
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $issues[] = ['crm_leads', $id, 'лид без владельца'];
    }
    return $issues;
}

/** DECIMAL из БД → строка для API: '45000' / '1234.50' / '' (как вводил пользователь, без хвоста .00). */
function crm_money_out(mixed $v): string {
    if ($v === null || $v === '') return '';
    $s = (string) $v;
    if (!str_contains($s, '.')) return $s;
    $s = rtrim(rtrim($s, '0'), '.');
    if (str_contains($s, '.')) {
        [$a, $b] = explode('.', $s, 2);
        $s = $a . '.' . str_pad($b, 2, '0');
    }
    return $s === '' ? '0' : $s;
}

/** Значение для записи в DECIMAL-колонку: '' → NULL. */
function crm_money_in(string $v): ?string {
    return $v === '' ? null : $v;
}

/*
 * Версия сборки для баннера «Вышло обновление»: авто-хэш клиентских и серверных файлов.
 * Специально не константа: ручную версию забывают поднять, а хэш меняется сам
 * при любом деплое. Считается раз за запрос (static); отдаётся в get_data —
 * клиент сравнивает с версией, на которой загрузился.
 */
function crm_build(): string {
    static $b = null;
    if ($b !== null) return $b;
    $files = [__DIR__ . '/index.html', __DIR__ . '/ui.html', __DIR__ . '/app.css', __DIR__ . '/noscript.css'];
    foreach (glob(__DIR__ . '/js/*.js') ?: [] as $f) $files[] = $f;
    // Бэкенд тоже входит в хэш (ревью §37, G8): контракт API мог измениться —
    // клиент со старым JS должен предложить перезагрузку, а не ломаться молча.
    foreach (['api.php', 'db.php', 'http.php', 'security.php', 'files.php', 'migrations.php'] as $f) $files[] = __DIR__ . '/' . $f;
    foreach (glob(__DIR__ . '/actions/*.php') ?: [] as $f) $files[] = $f;
    $h = '';
    foreach ($files as $f) {
        $m = is_readable($f) ? md5_file($f) : false;
        $h .= $m === false ? '0' : $m;
    }
    $b = substr(md5($h), 0, 12);
    return $b;
}

/*
 * Версия клиентского кода (?v= из index.html) — второй сигнал для баннера обновления.
 * Нужна в пару к crm_build(): хэш засекается первым поллингом и слепнет, если вкладка
 * пережила деплой на экране входа (первый get_data уже с новым хэшем), а ?v= клиент
 * знает про себя сам из своего <script> — эталон без дыр. Если формат index.html
 * изменится и версия не распарсится — вернётся '' и клиент тихо пропустит сигнал.
 */
function crm_client_v(): string {
    static $v = null;
    if ($v !== null) return $v;
    $v = '';
    $idx = is_readable(__DIR__ . '/index.html') ? file_get_contents(__DIR__ . '/index.html') : '';
    if ($idx !== '' && preg_match('/js\/app\.js\?v=([A-Za-z0-9_.-]+)/', $idx, $m)) $v = $m[1];
    return $v;
}

function crm_default_stages(): array {
    return ['Новый', 'Вышел на ЛПР', 'Потенциальный клиент', 'Сделали просчет', 'Разместили заявку', 'Уехали, ждем заявку'];
}

function crm_ensure_user_stages(PDO $pdo, int $userId): void {
    $st = $pdo->prepare('SELECT COUNT(*) FROM crm_stages WHERE user_id = ?');
    $st->execute([$userId]);
    if ((int) $st->fetchColumn() > 0) return;
    $ins = $pdo->prepare('INSERT INTO crm_stages (user_id, name, position) VALUES (?,?,?)');
    foreach (crm_default_stages() as $i => $name) $ins->execute([$userId, $name, $i]);
}

/**
 * Новый id с префиксом ('l_', 'a_', 'd_', 'k_', 'c_', 'cc_') с проверкой на коллизию.
 * 48 бит случайности — коллизия почти невероятна, но раньше при её наступлении INSERT
 * падал duplicate key → пользователь получал «Не удалось сохранить» без повтора.
 * Проверка по PK дешёвая; гонка двух одновременных вставок с одинаковым id прикрыта
 * самим PK (вторая упадёт), вероятность этого пренебрежима.
 */
function crm_new_id(PDO $pdo, string $prefix, string $table): string {
    static $tables = ['crm_leads', 'crm_lead_apps', 'crm_directions', 'crm_carriers', 'crm_comments', 'crm_carrier_comments', 'crm_app_comments'];
    if (!in_array($table, $tables, true)) return $prefix . bin2hex(random_bytes(6));
    for ($i = 0; $i < 3; $i++) {
        $id = $prefix . bin2hex(random_bytes(6));
        try {
            $st = $pdo->prepare("SELECT 1 FROM {$table} WHERE id = ?");
            $st->execute([$id]);
            if ($st->fetch() === false) return $id;
        } catch (PDOException $e) {
            return $id; // таблицы ещё нет (первый boot) — id заведомо свободен
        }
    }
    return $prefix . bin2hex(random_bytes(6));
}

function crm_norm_city(string $s): string {
    // preg_replace с /u возвращает null на невалидном UTF-8 — раньше trim(null) кидал TypeError (500)
    return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
}

function crm_direction_by_id(PDO $pdo, string $id): ?array {
    $st = $pdo->prepare('SELECT d.*, u.name AS creator FROM crm_directions d LEFT JOIN crm_users u ON u.id = d.created_by WHERE d.id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * Тихое дублирование маршрута новой заявки в справочник направлений: пара есть —
 * возвращаем её id, нет — создаём (автор — создатель заявки, как при ручном
 * добавлении) и возвращаем [id, true]. Гонка гасится повтором (до 2 попыток):
 * 1062 — это либо чужой uq_dir (повторный SELECT найдёт), либо коллизия
 * случайного id (повторный INSERT с новым id пройдёт). Исчерпали — исключение
 * наружу, save_lead_app откатит транзакцию (ревью §26, F3).
 * Вызывать ВНУТРИ транзакции save_lead_app.
 * @return array{string,bool} [directionId, created]
 */
function crm_ensure_direction(PDO $pdo, string $from, string $to, int $uid): array {
    $st = $pdo->prepare('SELECT id FROM crm_directions WHERE city_from = ? AND city_to = ?');
    for ($try = 0; ; $try++) {
        $st->execute([$from, $to]);
        $found = $st->fetchColumn();
        if ($found) return [(string) $found, false];
        $id = crm_new_id($pdo, 'd_', 'crm_directions');
        try {
            $pdo->prepare('INSERT INTO crm_directions (id, city_from, city_to, created_by, created_at) VALUES (?,?,?,?,?)')
                ->execute([$id, $from, $to, $uid, now_ms()]);
            return [$id, true];
        } catch (PDOException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) !== 1062 || $try > 0) throw $e;
        }
    }
}

/**
 * Тихое дублирование перевозчика новой заявки в справочник (на направление из
 * crm_ensure_direction): есть такой — возвращаем его id, нет — создаём.
 * Совпадение — по ИНН (если указан), иначе точное по компании/имени/телефону.
 * Нашли — чужие реквизиты не перезаписываем (первый побеждает, правится вручную).
 * Пустой перевозчик (все четыре поля пустые) — [null, false], ничего не пишем.
 * Имя обязательно (как в save_carrier): пустое подменяем компанией, телефоном,
 * в крайнем случае «ИНН …», иначе строка без названия.
 * Вызывать ВНУТРИ транзакции save_lead_app.
 * @return array{string|null,bool} [carrierId|null, created]
 */
function crm_ensure_carrier(PDO $pdo, string $dirId, array $f, int $uid): array {
    $company = (string) ($f['carrierCompany'] ?? '');
    $inn = (string) ($f['carrierInn'] ?? '');
    $name = (string) ($f['carrierName'] ?? '');
    $phone = (string) ($f['carrierPhone'] ?? '');
    if ($company === '' && $inn === '' && $name === '' && $phone === '') return [null, false];
    if ($inn !== '') {
        $st = $pdo->prepare('SELECT id FROM crm_carriers WHERE direction_id = ? AND inn = ?');
        $st->execute([$dirId, $inn]);
    } else {
        $st = $pdo->prepare('SELECT id FROM crm_carriers WHERE direction_id = ? AND company = ? AND name = ? AND phone = ?');
        $st->execute([$dirId, $company, $name, $phone]);
    }
    $found = $st->fetchColumn();
    if ($found) return [(string) $found, false];
    if ($name === '') $name = $company !== '' ? $company : ($phone !== '' ? $phone : 'ИНН ' . $inn);
    $id = crm_new_id($pdo, 'k_', 'crm_carriers');
    $now = now_ms();
    $pdo->prepare('INSERT INTO crm_carriers (id, direction_id, name, phone, company, inn, note, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
        ->execute([$id, $dirId, $name, $phone, $company, $inn, '', $uid, $now, $now]);
    return [$id, true];
}

function crm_directions_list(PDO $pdo, string $q = ''): array {
    $sql = 'SELECT d.id, d.city_from, d.city_to, d.created_by, d.created_at, u.name AS creator,
            (SELECT COUNT(*) FROM crm_carriers c WHERE c.direction_id = d.id) AS carriers_count
            FROM crm_directions d
            LEFT JOIN crm_users u ON u.id = d.created_by';
    $params = [];
    $q = trim($q);
    if ($q !== '') {
        $sql .= ' WHERE d.city_from LIKE ? OR d.city_to LIKE ?';
        $pat = crm_like_pat($q);
        $params = [$pat, $pat];
    }
    $sql .= ' ORDER BY d.city_from ASC, d.city_to ASC';
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $out = [];
    foreach ($st as $r) {
        $out[] = [
            'id' => $r['id'],
            'cityFrom' => $r['city_from'],
            'cityTo' => $r['city_to'],
            'carriersCount' => (int) $r['carriers_count'],
            'createdByName' => $r['creator'] ?: '',
        ];
    }
    return $out;
}

function crm_carriers_list(PDO $pdo, string $directionId, array $user = []): array {
    $st = $pdo->prepare('SELECT c.*, u.name AS creator,
            (SELECT COUNT(*) FROM crm_carrier_comments x WHERE x.carrier_id = c.id) AS comments_count
            FROM crm_carriers c LEFT JOIN crm_users u ON u.id = c.created_by
            WHERE c.direction_id = ? ORDER BY c.created_at ASC');
    $st->execute([$directionId]);
    $out = [];
    foreach ($st as $r) {
        $out[] = [
            'id' => $r['id'],
            'name' => $r['name'],
            'phone' => $r['phone'],
            'company' => $r['company'],
            'inn' => $r['inn'],
            'note' => $r['note'],
            'commentsCount' => (int) $r['comments_count'],
            'createdByName' => $r['creator'] ?: '',
            'canManage' => $user ? can_manage_ref($user, $r) : false,
            'updatedAt' => (int) ($r['updated_at'] ?? $r['created_at'] ?? 0),
        ];
    }
    return $out;
}

function crm_carrier_by_id(PDO $pdo, string $id): ?array {
    $st = $pdo->prepare('SELECT c.*, u.name AS creator FROM crm_carriers c LEFT JOIN crm_users u ON u.id = c.created_by WHERE c.id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

function crm_carrier_comments(PDO $pdo, string $carrierId): array {
    $st = $pdo->prepare('SELECT c.*, u.name AS live_name FROM crm_carrier_comments c LEFT JOIN crm_users u ON u.id = c.user_id AND c.user_id > 0 WHERE c.carrier_id = ? ORDER BY c.time ASC');
    $st->execute([$carrierId]);
    $comments = [];
    $ids = [];
    foreach ($st as $c) {
        $isSys = crm_is_sys_comment($c);
        $item = [
            'id' => $c['id'],
            'text' => $c['text'],
            'author' => (trim((string) ($c['live_name'] ?? '')) !== '' ? $c['live_name'] : $c['author']),
            'userId' => (int) ($c['user_id'] ?? 0),
            'time' => (int) $c['time'],
            'isSystem' => $isSys,
            'attachments' => [],
        ];
        if ($c['edited_at'] !== null) $item['editedAt'] = (int) $c['edited_at'];
        $comments[$c['id']] = $item;
        $ids[] = $c['id'];
    }
    if ($ids) {
        $inQ = implode(',', array_fill(0, count($ids), '?'));
        $att = $pdo->prepare("SELECT * FROM crm_carrier_attachments WHERE comment_id IN ($inQ) ORDER BY id ASC");
        $att->execute($ids);
        foreach ($att as $a) {
            if (!isset($comments[$a['comment_id']])) continue;
            $comments[$a['comment_id']]['attachments'][] = [
                'id' => (int) $a['id'],
                'name' => $a['name'],
                'size' => (int) $a['size'],
                'type' => crm_att_mime((string) $a['type'], (string) $a['data_url'], (string) $a['name']),
                'dataUrl' => crm_file_url((string) $a['data_url']),
            ];
        }
    }
    return array_values($comments);
}

function crm_carrier_comment_by_id(PDO $pdo, string $cid): ?array {
    $st = $pdo->prepare('SELECT * FROM crm_carrier_comments WHERE id = ?');
    $st->execute([$cid]);
    $row = $st->fetch();
    return $row ?: null;
}

function crm_touch_lead(PDO $pdo, string $id): int {
    $now = now_ms();
    $pdo->prepare('UPDATE crm_leads SET updated_at = ? WHERE id = ?')->execute([$now, $id]);
    return $now;
}

function crm_touch_carrier(PDO $pdo, string $id): int {
    $now = now_ms();
    $pdo->prepare('UPDATE crm_carriers SET updated_at = ? WHERE id = ?')->execute([$now, $id]);
    return $now;
}

/**
 * Новая ревизия заявки (v20): лог заявки трогает только свою заявку, а не лид —
 * иначе каждая реплика в логе переупорядочивала бы доску. Поля/статус заявки,
 * видимые на карточках лида и в реестре, дополнительно трогают лид (save_app,
 * set_app_status, save_lead_app) — по образцу save_lead_app.
 */
function crm_touch_app(PDO $pdo, string $id): int {
    $now = now_ms();
    $pdo->prepare('UPDATE crm_lead_apps SET updated_at = ? WHERE id = ?')->execute([$now, $id]);
    return $now;
}

function crm_purge_lead(PDO $pdo, string $id, bool $ownTxn = true): array {
    $cidsSt = $pdo->prepare('SELECT id FROM crm_comments WHERE lead_id = ?');
    $cidsSt->execute([$id]);
    $cids = $cidsSt->fetchAll(PDO::FETCH_COLUMN);
    $urls = crm_att_urls($pdo, 'crm_attachments', $cids);
    // v20: логи заявок лида (комментарии + вложения) — иначе удаление лида
    // оставляло бы сирот в crm_app_comments и файлы без записей.
    $appSt = $pdo->prepare('SELECT id FROM crm_lead_apps WHERE lead_id = ?');
    $appSt->execute([$id]);
    $appIds = $appSt->fetchAll(PDO::FETCH_COLUMN);
    $acids = [];
    if ($appIds) {
        $inQ = implode(',', array_fill(0, count($appIds), '?'));
        $acSt = $pdo->prepare("SELECT id FROM crm_app_comments WHERE app_id IN ($inQ)");
        $acSt->execute($appIds);
        $acids = $acSt->fetchAll(PDO::FETCH_COLUMN);
    }
    $urls = array_merge($urls, crm_att_urls($pdo, 'crm_app_attachments', $acids));
    $start = $ownTxn && !$pdo->inTransaction();
    if ($start) $pdo->beginTransaction();
    try {
        crm_delete_att_rows($pdo, 'crm_attachments', $cids);
        $pdo->prepare('DELETE FROM crm_comments WHERE lead_id = ?')->execute([$id]);
        crm_delete_att_rows($pdo, 'crm_app_attachments', $acids);
        if ($acids) {
            $inQ = implode(',', array_fill(0, count($acids), '?'));
            $pdo->prepare("DELETE FROM crm_app_comments WHERE id IN ($inQ)")->execute($acids);
        }
        try { $pdo->prepare('DELETE FROM crm_lead_apps WHERE lead_id = ?')->execute([$id]); } catch (PDOException $e) { /* v8 */ }
        try { $pdo->prepare('DELETE FROM crm_lead_tags WHERE lead_id = ?')->execute([$id]); } catch (PDOException $e) { /* v17 */ }
        $pdo->prepare('DELETE FROM crm_leads WHERE id = ?')->execute([$id]);
        if ($start) $pdo->commit();
    } catch (Throwable $e) {
        if ($start && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    if ($ownTxn) {
        crm_unlink_urls($urls);
        return [];
    }
    return $urls;
}

/**
 * Передать один лид от $fromUid к $toId (внутри уже открытой транзакции).
 * Этап сохраняется, если такой есть у получателя, иначе — первый этап получателя.
 * $viaName — кто фактически передал (админ через ?as=), пусто если сам владелец.
 * Возвращает [имя получателя, записанная ревизия updated_at] или null при ошибке.
 */
function crm_transfer_lead(PDO $pdo, string $leadId, int $fromUid, int $toId, string $fromName, string $stage, string $viaName = '', int $updatedAt = 0): ?array {
    $to = crm_user_by_id($pdo, $toId);
    if (!$to) return null;
    $toName = (string) $to['name'];
    $toStages = crm_stages($pdo, $toId);
    $newStage = in_array($stage, $toStages, true) ? $stage : ($toStages[0] ?? $stage);
    $now = now_ms();
    $tr = $pdo->prepare('UPDATE crm_leads SET user_id = ?, stage = ?, manager = ?, updated_at = ? WHERE id = ? AND user_id = ? AND updated_at = ? AND deleted_at = 0');
    $tr->execute([$toId, $newStage, $toName, $now, $leadId, $fromUid, $updatedAt]);
    if ($tr->rowCount() === 0) return null;
    // Теги личные (v17): при передаче привязки прежнего владельца снимаются —
    // получатель не видит чужой справочник, а «мёртвые» ссылки не копятся.
    try { $pdo->prepare('DELETE FROM crm_lead_tags WHERE lead_id = ?')->execute([$leadId]); } catch (PDOException $e) { /* до v17 */ }
    $via = $viaName !== '' ? ' (передал ' . $viaName . ')' : '';
    crm_sys_comment($pdo, $leadId, 'Лид передан: ' . $fromName . ' → ' . $toName . $via);
    return [$toName, $now];
}

/**
 * Передать все лиды сотрудника $from сотруднику $to (внутри уже открытой транзакции).
 * Этап сохраняется, если такой есть у получателя, иначе — первый этап получателя.
 * Возвращает число переданных лидов.
 */
function crm_transfer_user_leads(PDO $pdo, int $from, int $to, string $fromName, string $toName): int {
    $toStages = crm_stages($pdo, $to);
    $fallback = $toStages[0] ?? 'Новый';
    // Только активные: корзина увольняемого допурживается вызывающим (ревью §37, G1)
    $st = $pdo->prepare('SELECT id, stage FROM crm_leads WHERE user_id = ? AND deleted_at = 0');
    $st->execute([$from]);
    $rows = $st->fetchAll();
    if (!$rows) return 0;
    $upd = $pdo->prepare('UPDATE crm_leads SET user_id = ?, stage = ?, manager = ?, updated_at = ? WHERE id = ? AND user_id = ?');
    $n = 0;
    foreach ($rows as $r) {
        $stage = in_array((string) $r['stage'], $toStages, true) ? (string) $r['stage'] : $fallback;
        $upd->execute([$to, $stage, $toName, now_ms(), (string) $r['id'], $from]);
        crm_sys_comment($pdo, (string) $r['id'], 'Лид передан: ' . $fromName . ' → ' . $toName . ' (сотрудник удалён)');
        $n++;
    }
    return $n;
}

/**
 * Удалить сотрудника. $transferTo > 0 — его лиды (с логом, вложениями и заявками) уходят
 * другому сотруднику; 0 — лиды и их файлы удаляются безвозвратно.
 * Возвращает число переданных лидов.
 */
function crm_purge_user(PDO $pdo, int $id, int $transferTo = 0): int {
    $urls = [];
    $moved = 0;
    $pdo->beginTransaction();
    try {
        if ($transferTo > 0) {
            $from = crm_user_by_id($pdo, $id);
            $to = crm_user_by_id($pdo, $transferTo);
            if (!$to || $transferTo === $id) throw new RuntimeException('bad transfer target');
            $moved = crm_transfer_user_leads($pdo, $id, $transferTo, (string) ($from['name'] ?? ''), (string) $to['name']);
            // Корзина увольняемого новому владельцу не переходит (ревью §37, G1):
            // чужой мусор в чужой корзине ни к чему — допурживаем вместе с файлами.
            $del = $pdo->prepare('SELECT id FROM crm_leads WHERE user_id = ? AND deleted_at <> 0');
            $del->execute([$id]);
            foreach ($del->fetchAll(PDO::FETCH_COLUMN) as $lid) {
                $urls = array_merge($urls, crm_purge_lead($pdo, (string) $lid, false));
            }
        } else {
            $st = $pdo->prepare('SELECT id FROM crm_leads WHERE user_id = ?');
            $st->execute([$id]);
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $lid) {
                $urls = array_merge($urls, crm_purge_lead($pdo, (string) $lid, false));
            }
        }
        $pdo->prepare('DELETE FROM crm_stages WHERE user_id = ?')->execute([$id]);
        // Личные теги сотрудника и их привязки (v17): без чистки остались бы записи-сироты
        try {
            $pdo->prepare('DELETE lt FROM crm_lead_tags lt INNER JOIN crm_tags t ON t.id = lt.tag_id WHERE t.user_id = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM crm_tags WHERE user_id = ?')->execute([$id]);
        } catch (PDOException $e) { /* до v17 */ }
        $pdo->prepare('UPDATE crm_directions SET created_by = 0 WHERE created_by = ?')->execute([$id]);
        $pdo->prepare('UPDATE crm_carriers SET created_by = 0 WHERE created_by = ?')->execute([$id]);
        $pdo->prepare('UPDATE crm_carrier_comments SET user_id = 0 WHERE user_id = ?')->execute([$id]);
        $pdo->prepare('UPDATE crm_comments SET user_id = 0 WHERE user_id = ?')->execute([$id]);
        // Лог заявок (v20) — как лог лидов: иначе user_id болтался бы после увольнения (ревью §37, G6)
        $pdo->prepare('UPDATE crm_app_comments SET user_id = 0 WHERE user_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM crm_users WHERE id = ?')->execute([$id]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    crm_unlink_urls($urls);
    return $moved;
}

function crm_purge_carrier(PDO $pdo, string $id, bool $ownTxn = true): array {
    $cidsSt = $pdo->prepare('SELECT id FROM crm_carrier_comments WHERE carrier_id = ?');
    $cidsSt->execute([$id]);
    $ids = $cidsSt->fetchAll(PDO::FETCH_COLUMN);
    $urls = crm_att_urls($pdo, 'crm_carrier_attachments', $ids);
    $start = $ownTxn && !$pdo->inTransaction();
    if ($start) $pdo->beginTransaction();
    try {
        crm_delete_att_rows($pdo, 'crm_carrier_attachments', $ids);
        if ($ids) $pdo->prepare('DELETE FROM crm_carrier_comments WHERE carrier_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM crm_carriers WHERE id = ?')->execute([$id]);
        if ($start) $pdo->commit();
    } catch (Throwable $e) {
        if ($start && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    if ($ownTxn) {
        crm_unlink_urls($urls);
        return [];
    }
    return $urls;
}

/**
 * Алгоритм хэширования паролей (код-ревью п. 3.4): Argon2id, если PHP собран с ним
 * (на SpaceWeb PHP 8.1+ обычно да), иначе bcrypt. Существующие bcrypt-хэши продолжают
 * работать; при успешном входе password_needs_rehash() перекладывает их на новый
 * алгоритм — плавная миграция без сброса паролей.
 */
function crm_password_algo(): string {
    return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
}
function crm_password_hash(string $pass): string {
    return password_hash($pass, crm_password_algo());
}
/** Хэш выглядит как валидный (bcrypt или argon2) — для подмены на dummy при защите от тайминга. */
function crm_hash_looks_valid(string $hash): bool {
    return (bool) preg_match('/^\$(2[aby]|argon2id?)\$/', $hash);
}
/**
 * Dummy-хэш для защиты от перечисления пользователей по таймингу (ревью, п. 12.2).
 * Обязан быть создан ТЕМ ЖЕ алгоритмом, что и боевые хэши (crm_password_algo):
 * раньше это была bcrypt-константа, и после миграции паролей на Argon2id время
 * password_verify() для несуществующего e-mail (bcrypt, ~100 мс) отличалось от
 * существующего (argon2id) — e-mail снова можно было перечислять по времени ответа.
 * Считается один раз на процесс; пароль в нём случайный — verify всегда провалится.
 */
function crm_dummy_hash(): string {
    static $dummy = null;
    if ($dummy === null) $dummy = crm_password_hash(bin2hex(random_bytes(16)));
    return $dummy;
}

function crm_user_public(array $u): array {
    return ['id' => (int) $u['id'], 'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role']];
}

/** @throws CrmError если ?as= использует не-админ или сотрудник не существует (TODO #20) */
function crm_view_uid(PDO $pdo, array $user): int {
    $as = is_scalar($_GET['as'] ?? null) ? (int) $_GET['as'] : 0;
    if ($as <= 0) return (int) $user['id'];
    // CrmError вместо err() (TODO #20) — тексты те же, crm_err_status даст те же 403/404
    if (($user['role'] ?? '') !== 'admin') throw new CrmError('Нет прав');
    if ($as === (int) $user['id']) return $as;
    if (!crm_user_by_id($pdo, $as)) throw new CrmError('Сотрудник не найден');
    return $as;
}

function crm_search_employees(PDO $pdo, string $q): array {
    $q = trim($q);
    if ($q === '') return [];
    $st = $pdo->prepare('SELECT id, name FROM crm_users WHERE name LIKE ? ORDER BY name ASC LIMIT 20');
    $st->execute([crm_like_pat($q)]);
    $out = [];
    foreach ($st as $r) $out[] = ['id' => (int) $r['id'], 'name' => $r['name']];
    return $out;
}

function crm_colleagues(PDO $pdo): array {
    $out = [];
    foreach ($pdo->query('SELECT id, name FROM crm_users ORDER BY name ASC') as $u) {
        $out[] = ['id' => (int) $u['id'], 'name' => $u['name']];
    }
    return $out;
}

function crm_user_by_id(PDO $pdo, int $id): ?array {
    $st = $pdo->prepare('SELECT * FROM crm_users WHERE id = ?');
    $st->execute([$id]);
    $u = $st->fetch();
    return $u ?: null;
}

function crm_user_by_email(PDO $pdo, string $email): ?array {
    $st = $pdo->prepare('SELECT * FROM crm_users WHERE email = ?');
    $st->execute([mb_strtolower($email)]);
    $u = $st->fetch();
    return $u ?: null;
}

function crm_stages(PDO $pdo, int $userId): array {
    $st = $pdo->prepare('SELECT name FROM crm_stages WHERE user_id = ? ORDER BY position ASC, id ASC');
    $st->execute([$userId]);
    return array_map(fn($r) => $r['name'], $st->fetchAll());
}

function crm_lead_for_user(PDO $pdo, string $id, int $userId): ?array {
    // §35: гейт видит только активные свои — все мутации автоматом закрыты для удалённых.
    $st = $pdo->prepare('SELECT * FROM crm_leads WHERE id = ? AND user_id = ? AND deleted_at = 0');
    $st->execute([$id, $userId]);
    $row = $st->fetch();
    return $row ?: null;
}

/** Удалённый лид любого владельца (§35): только чтение + restore/purge. */
function crm_deleted_lead(PDO $pdo, string $id): ?array {
    $st = $pdo->prepare('SELECT * FROM crm_leads WHERE id = ? AND deleted_at <> 0');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * Статусы заявки (v20): 0 «В работе», 1 «Машина загрузилась», 2 «Машина выгрузилась».
 * Хранится TINYINT в crm_lead_apps.status; переходы свободные, валидация —
 * array_key_exists по этой карте. Подписи дублируются на клиенте
 * (APP_STATUS_LABELS в js/lead.js): при добавлении статуса править оба места.
 */
function crm_app_statuses(): array {
    return [0 => 'В работе', 1 => 'Машина загрузилась', 2 => 'Машина выгрузилась'];
}

function crm_lead_app_to_api(array $r): array {
    return [
        'id' => $r['id'],
        'leadId' => $r['lead_id'],
        'number' => (string) ($r['number'] ?? ''),
        'status' => (int) ($r['status'] ?? 0),
        'cityFrom' => $r['city_from'],
        'cityTo' => $r['city_to'],
        'rate' => crm_money_out($r['rate'] ?? null),
        'margin' => crm_money_out($r['margin'] ?? null),
        'vat' => ($r['vat'] ?? null) === null ? null : (int) $r['vat'],
        'carrierRate' => crm_money_out($r['carrier_rate'] ?? null),
        'carrierVat' => ($r['carrier_vat'] ?? null) === null ? null : (int) $r['carrier_vat'],
        'carrierCompany' => $r['carrier_company'],
        'carrierInn' => $r['carrier_inn'],
        'carrierName' => $r['carrier_name'],
        'carrierPhone' => $r['carrier_phone'],
        'loadAddress' => $r['load_address'],
        'loadContact' => $r['load_contact'],
        'loadDateFrom' => $r['load_date_from'],
        'loadDateTo' => $r['load_date_to'],
        'loadTime' => $r['load_time'],
        'unloadAddress' => $r['unload_address'],
        'unloadContact' => $r['unload_contact'],
        'unloadDateFrom' => $r['unload_date_from'],
        'unloadDateTo' => $r['unload_date_to'],
        'unloadTime' => $r['unload_time'],
        'createdAt' => (int) $r['created_at'],
        'updatedAt' => (int) ($r['updated_at'] ?? $r['created_at'] ?? 0),
    ];
}

function crm_lead_apps(PDO $pdo, string $leadId): array {
    try {
        $st = $pdo->prepare('SELECT * FROM crm_lead_apps WHERE lead_id = ? ORDER BY created_at ASC, id ASC');
        $st->execute([$leadId]);
    } catch (PDOException $e) {
        return [];
    }
    $out = [];
    foreach ($st as $r) $out[] = crm_lead_app_to_api($r);
    return $out;
}

function crm_lead_app_by_id(PDO $pdo, string $id): ?array {
    try {
        $st = $pdo->prepare('SELECT * FROM crm_lead_apps WHERE id = ?');
        $st->execute([$id]);
    } catch (PDOException $e) {
        return null;
    }
    $row = $st->fetch();
    return $row ?: null;
}

function crm_parse_money(mixed $v): ?string {
    $s = trim(str_replace(["\xC2\xA0", ' ', "\t"], '', (string) $v));
    if ($s === '') return '';
    $s = rtrim(str_replace(',', '.', $s), '.');
    if (!preg_match('/^\d{1,12}(\.\d{1,2})?$/', $s)) return null;
    if (str_contains($s, '.')) {
        [$a, $b] = explode('.', $s, 2);
        $s = $a . '.' . str_pad($b, 2, '0');
    }
    return $s;
}

function crm_apps_stats(PDO $pdo, int $userId, string $leadId, string $inn = ''): array {
    $zero = ['count' => 0, 'margin' => 0, 'clientCount' => 0, 'clientMargin' => 0];
    $sumSql = 'COUNT(*) AS c, COALESCE(SUM(margin), 0) AS m';
    try {
        $st = $pdo->prepare("SELECT $sumSql FROM crm_lead_apps WHERE lead_id = ?");
        $st->execute([$leadId]);
        $row = $st->fetch() ?: ['c' => 0, 'm' => 0];
    } catch (PDOException $e) {
        return $zero;
    }
    $count = (int) $row['c'];
    $margin = round((float) $row['m'], 2);
    $clientCount = $count;
    $clientMargin = $margin;
    $inn = preg_replace('/\D/', '', $inn) ?? '';
    if (strlen($inn) === 10 || strlen($inn) === 12) {
        try {
            $st = $pdo->prepare("SELECT $sumSql FROM crm_lead_apps a INNER JOIN crm_leads l ON l.id = a.lead_id WHERE l.user_id = ? AND l.inn = ? AND l.deleted_at = 0");
            $st->execute([$userId, $inn]);
            $all = $st->fetch() ?: ['c' => 0, 'm' => 0];
            $clientCount = (int) $all['c'];
            $clientMargin = round((float) $all['m'], 2);
        } catch (PDOException $e) { /* keep lead totals */ }
    }
    return ['count' => $count, 'margin' => $margin, 'clientCount' => $clientCount, 'clientMargin' => $clientMargin];
}

/**
 * Общая валидация полей заявки для save_lead_app (модалка из лида) и save_app
 * (детальная страница). Возвращает нормализованные значения; при ошибке бросает
 * CrmError с тем же текстом, что раньше отдавал save_lead_app через err()
 * (db.php не завершает запрос сам — TODO #20; ответ байт в байт, см. catch в api.php).
 */
/**
 * Дата точки (§29): '' или ГГГГ-ММ-ДД из <input type="date">. Формат проверяет
 * и браузер, но API доверять ему нельзя — валидируем и календарность.
 * @throws CrmError
 */
function crm_app_date(string $v, string $label): string {
    if ($v === '') return '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) throw new CrmError($label . ': ГГГГ-ММ-ДД');
    [$y, $m, $d] = array_map('intval', explode('-', $v));
    if (!checkdate($m, $d, $y)) throw new CrmError($label . ': нет такой даты');
    return $v;
}

function crm_validate_app_fields(array $in): array {
    $number = strv($in['number'] ?? '', 40);
    $from = crm_norm_city(strv($in['cityFrom'] ?? '', 80));
    $to = crm_norm_city(strv($in['cityTo'] ?? '', 80));
    if ($from === '' || $to === '') throw new CrmError('Укажите откуда и куда');
    // Ставка и маржа парсятся одинаково строго: раньше из ставки молча вырезались не-цифры
    // и «12 500,50» превращалось в 1250050.
    $rate = crm_parse_money(strv($in['rate'] ?? '', 40));
    if ($rate === null) throw new CrmError('Ставка: число, копейки через запятую');
    $rate = crm_money_in($rate);
    $margin = crm_parse_money(strv($in['margin'] ?? '', 40));
    if ($margin === null) throw new CrmError('Маржа: число, копейки через запятую');
    $margin = crm_money_in($margin);
    // Налоги — строгий список режимов (v19); пусто = без НДС (NULL). Раньше был флаг 0/1.
    $vatRaw = strv($in['vat'] ?? '', 3);
    if (!in_array($vatRaw, ['', '0', '5', '7', '22'], true)) throw new CrmError('Налоги заказчика: выберите из списка');
    $vat = $vatRaw === '' ? null : (int) $vatRaw;
    $carrierVatRaw = strv($in['carrierVat'] ?? '', 3);
    if (!in_array($carrierVatRaw, ['', '0', '5', '7', '22'], true)) throw new CrmError('Налоги перевозчика: выберите из списка');
    $carrierVat = $carrierVatRaw === '' ? null : (int) $carrierVatRaw;
    $carrierRate = crm_parse_money(strv($in['carrierRate'] ?? '', 40));
    if ($carrierRate === null) throw new CrmError('Ставка перевозчику: число, копейки через запятую');
    $carrierRate = crm_money_in($carrierRate);
    $loadAddress = strv($in['loadAddress'] ?? '', 300);
    $loadContact = strv($in['loadContact'] ?? '', 120);
    $loadDateFrom = crm_app_date(strv($in['loadDateFrom'] ?? '', 10), 'Дата погрузки с');
    $loadDateTo = crm_app_date(strv($in['loadDateTo'] ?? '', 10), 'Дата погрузки по');
    $loadTime = strv($in['loadTime'] ?? '', 120);
    $unloadAddress = strv($in['unloadAddress'] ?? '', 300);
    $unloadContact = strv($in['unloadContact'] ?? '', 120);
    $unloadDateFrom = crm_app_date(strv($in['unloadDateFrom'] ?? '', 10), 'Дата выгрузки с');
    $unloadDateTo = crm_app_date(strv($in['unloadDateTo'] ?? '', 10), 'Дата выгрузки по');
    $unloadTime = strv($in['unloadTime'] ?? '', 120);
    $company = strv($in['carrierCompany'] ?? '', 200);
    // 20 символов до вырезания цифр: «7 701 000 001» с пробелами иначе резался и браковался (ревью §37, G18)
    $inn = preg_replace('/\D/', '', strv($in['carrierInn'] ?? '', 20)) ?? '';
    if ($inn !== '' && strlen($inn) !== 10 && strlen($inn) !== 12) throw new CrmError('ИНН 10 или 12 цифр');
    return [
        'number' => $number,
        'cityFrom' => $from,
        'cityTo' => $to,
        'rate' => $rate,
        'margin' => $margin,
        'vat' => $vat,
        'carrierRate' => $carrierRate,
        'carrierVat' => $carrierVat,
        'carrierCompany' => $company,
        'carrierInn' => $inn,
        'carrierName' => strv($in['carrierName'] ?? '', 80),
        'carrierPhone' => strv($in['carrierPhone'] ?? '', 40),
        'loadAddress' => $loadAddress,
        'loadContact' => $loadContact,
        'loadDateFrom' => $loadDateFrom,
        'loadDateTo' => $loadDateTo,
        'loadTime' => $loadTime,
        'unloadAddress' => $unloadAddress,
        'unloadContact' => $unloadContact,
        'unloadDateFrom' => $unloadDateFrom,
        'unloadDateTo' => $unloadDateTo,
        'unloadTime' => $unloadTime,
    ];
}

/**
 * Заявка, видимая сотруднику: сама строка + проверка, что лид-владелец
 * на его доске. Прав на заявку отдельно от лида нет (решение штурма).
 */
function crm_app_for_user(PDO $pdo, string $appId, int $viewUid): ?array {
    $app = $appId === '' ? null : crm_lead_app_by_id($pdo, $appId);
    if (!$app) return null;
    if (!crm_lead_for_user($pdo, (string) $app['lead_id'], $viewUid)) return null;
    return $app;
}

function crm_sync_lead_apps_count(PDO $pdo, string $leadId): int {
    try {
        $st = $pdo->prepare('SELECT COUNT(*) FROM crm_lead_apps WHERE lead_id = ?');
        $st->execute([$leadId]);
        $n = (int) $st->fetchColumn();
    } catch (PDOException $e) {
        $n = 0;
    }
    $pdo->prepare('UPDATE crm_leads SET applications_count = ? WHERE id = ?')->execute([$n, $leadId]);
    return $n;
}

function crm_comment_for_user(PDO $pdo, string $cid, int $userId): ?array {
    $st = $pdo->prepare('SELECT c.* FROM crm_comments c INNER JOIN crm_leads l ON l.id = c.lead_id WHERE c.id = ? AND l.user_id = ? AND l.deleted_at = 0');
    $st->execute([$cid, $userId]);
    $row = $st->fetch();
    return $row ?: null;
}

/**
 * Запись лога заявки, видимая сотруднику (v20): цепочка комментарий → заявка →
 * лид → владелец доски. Права на лог = права на лид (решение штурма).
 * Заморозка §35, как у лога лида: лид в корзине — правки закрыты (ревью §37, F3).
 */
function crm_app_comment_for_user(PDO $pdo, string $cid, int $userId): ?array {
    $st = $pdo->prepare('SELECT c.* FROM crm_app_comments c INNER JOIN crm_lead_apps a ON a.id = c.app_id INNER JOIN crm_leads l ON l.id = a.lead_id WHERE c.id = ? AND l.user_id = ? AND l.deleted_at = 0');
    $st->execute([$cid, $userId]);
    $row = $st->fetch();
    return $row ?: null;
}

function crm_lead_row_to_api(array $r, bool $full = true): array {
    $out = [
        'id' => $r['id'],
        'title' => $r['title'],
        'inn' => $r['inn'],
        'phone' => $r['phone'],
        'manager' => $r['manager'],
        'applicationsCount' => (int) $r['applications_count'],
        'stage' => $r['stage'],
        'createdAt' => (int) $r['created_at'],
        'updatedAt' => (int) ($r['updated_at'] ?? $r['created_at'] ?? 0),
        // Телефон логиста нужен и в лёгкой выборке: карточка на доске показывает его
        // вместо телефона лида (телефон лида из карточки убран — заменён на Код АТИ).
        'logistPhone' => $r['logist_phone'] ?? '',
    ];
    if ($full) {
        $out['email'] = $r['email'];
        $out['ati'] = $r['ati'] ?? '';
        $out['logistName'] = $r['logist_name'] ?? '';
        $out['deleted'] = ((int) ($r['deleted_at'] ?? 0)) !== 0;
        $out['deletedAt'] = (int) ($r['deleted_at'] ?? 0);
    }
    return $out;
}

function crm_leads_full(PDO $pdo, int $userId): array {
    $st = $pdo->prepare('SELECT id, title, inn, phone, logist_phone, manager, applications_count, stage, created_at, updated_at FROM crm_leads WHERE user_id = ? AND deleted_at = 0 ORDER BY created_at ASC');
    $st->execute([$userId]);
    $leads = [];
    foreach ($st as $r) $leads[] = crm_lead_row_to_api($r, false);
    return $leads;
}

// --- Теги лидов (v17) --------------------------------------------------------
// Палитра фиксированная: сервер принимает только эти цвета. Клиент превращает hex
// в CSS-класс .tag-c-<hex> (CSP style-src 'self' запрещает inline-style), поэтому
// произвольные строки в color не допускаются; та же палитра — TAG_COLORS в js/lead.js.
const CRM_TAG_COLORS = ['#ef4444', '#f97316', '#f59e0b', '#22c55e', '#14b8a6', '#3b82f6', '#6366f1', '#a855f7', '#ec4899', '#64748b'];

/** Цвет тега: значение из палитры или цвет по умолчанию (индиго). */
function crm_tag_color(string $c): string {
    return in_array($c, CRM_TAG_COLORS, true) ? $c : '#6366f1';
}

/** Личный справочник тегов сотрудника (для окна «Теги» и модалки выбора). */
function crm_tags_for_user(PDO $pdo, int $uid): array {
    try {
        $st = $pdo->prepare('SELECT id, name, color FROM crm_tags WHERE user_id = ? ORDER BY name');
        $st->execute([$uid]);
        $out = [];
        foreach ($st as $r) $out[] = ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'color' => (string) $r['color']];
        return $out;
    } catch (PDOException $e) {
        return []; // до миграции v17
    }
}

/**
 * Карта lead_id → теги владельца $uid: один JOIN на все лиды доски (get_data),
 * вместо запроса на каждый лид. INNER JOIN по t.user_id отсекает чужие теги,
 * даже если в crm_lead_tags остались ссылки (их чистят передача/удаление).
 */
function crm_lead_tags_map(PDO $pdo, int $uid): array {
    $map = [];
    try {
        $st = $pdo->prepare('SELECT lt.lead_id, t.id, t.name, t.color FROM crm_lead_tags lt INNER JOIN crm_tags t ON t.id = lt.tag_id WHERE t.user_id = ? ORDER BY t.name');
        $st->execute([$uid]);
        foreach ($st as $r) {
            $map[(string) $r['lead_id']][] = ['id' => (int) $r['id'], 'name' => (string) $r['name'], 'color' => (string) $r['color']];
        }
    } catch (PDOException $e) { /* до миграции v17 */ }
    return $map;
}

function crm_admin_count(PDO $pdo): int {
    return (int) $pdo->query("SELECT COUNT(*) FROM crm_users WHERE role = 'admin'")->fetchColumn();
}

/**
 * Комментарии (лида или заявки) + их вложения одним запросом.
 * $attTable: 'crm_attachments' | 'crm_app_attachments' — литералом из call-site'а
 * (не из ввода пользователя), как имена таблиц в crm_insert_comment.
 */
function crm_comments_payload(PDO $pdo, array $rows, string $attTable = 'crm_attachments'): array {
    $byComment = [];
    $order = [];
    foreach ($rows as $c) {
        $isSys = crm_is_sys_comment($c);
        $item = [
            'id' => $c['id'],
            'text' => $c['text'],
            'author' => (trim((string) ($c['live_name'] ?? '')) !== '' ? $c['live_name'] : $c['author']),
            'userId' => (int) ($c['user_id'] ?? 0),
            'time' => (int) $c['time'],
            'isSystem' => $isSys,
            'attachments' => [],
        ];
        if ($c['edited_at'] !== null) $item['editedAt'] = (int) $c['edited_at'];
        $byComment[$c['id']] = $item;
        $order[] = $c['id'];
    }
    if ($byComment) {
        $cids = array_keys($byComment);
        $inQ = implode(',', array_fill(0, count($cids), '?'));
        $st = $pdo->prepare("SELECT * FROM {$attTable} WHERE comment_id IN ($inQ) ORDER BY id ASC");
        $st->execute($cids);
        foreach ($st as $a) {
            if (!isset($byComment[$a['comment_id']])) continue;
            $byComment[$a['comment_id']]['attachments'][] = [
                'id' => (int) $a['id'],
                'name' => $a['name'],
                'size' => (int) $a['size'],
                'type' => crm_att_mime((string) $a['type'], (string) $a['data_url'], (string) $a['name']),
                'dataUrl' => crm_file_url((string) $a['data_url']),
            ];
        }
    }
    return array_map(fn($cid) => $byComment[$cid], $order);
}

function crm_lead_comments(PDO $pdo, string $leadId): array {
    $st = $pdo->prepare('SELECT c.*, u.name AS live_name FROM crm_comments c LEFT JOIN crm_users u ON u.id = c.user_id AND c.user_id > 0 WHERE c.lead_id = ? ORDER BY c.time ASC');
    $st->execute([$leadId]);
    return crm_comments_payload($pdo, $st->fetchAll());
}

/** Лог заявки (v20): тот же payload, что у лида (текст + до 8 вложений), владелец — app_id. */
function crm_app_comments(PDO $pdo, string $appId): array {
    $st = $pdo->prepare('SELECT c.*, u.name AS live_name FROM crm_app_comments c LEFT JOIN crm_users u ON u.id = c.user_id AND c.user_id > 0 WHERE c.app_id = ? ORDER BY c.time ASC');
    $st->execute([$appId]);
    return crm_comments_payload($pdo, $st->fetchAll(), 'crm_app_attachments');
}

/**
 * Системная запись в лог. По умолчанию — лог лида; для заявки передаются
 * таблица crm_app_comments, колонка app_id и префикс id 'ac_'.
 */
function crm_sys_comment(PDO $pdo, string $ownerId, string $text, string $table = 'crm_comments', string $ownerCol = 'lead_id', string $prefix = 'c_'): void {
    $st = $pdo->prepare("INSERT INTO {$table} (id, {$ownerCol}, text, author, user_id, time, edited_at) VALUES (?,?,?,?,0,?,NULL)");
    $st->execute([crm_new_id($pdo, $prefix, $table), $ownerId, $text, 'Система', now_ms()]);
}

/**
 * Системные записи об изменении ставок/перевозчика (v20): сравнивает старые
 * значения заявки ($old — строка БД) с новыми ($f — crm_validate_app_fields)
 * и пишет в лог заявки («Ставка заказчика: 45000 ➔ 50000»).
 * Вызывается внутри транзакции save_lead_app/save_app; логируются только ставки
 * и перевозчик (решение штурма), остальные поля — нет. Сравнение через
 * crm_money_out с обеих сторон: '45000.00' из DECIMAL и '45000' из формы равны.
 */
function crm_app_sys_field_changes(PDO $pdo, string $appId, array $old, array $f): void {
    $pairs = [
        ['Ставка заказчика', crm_money_out($old['rate'] ?? null), crm_money_out($f['rate'] ?? null)],
        ['Ставка перевозчика', crm_money_out($old['carrier_rate'] ?? null), crm_money_out($f['carrierRate'] ?? null)],
        ['Перевозчик', (string) ($old['carrier_company'] ?? ''), (string) ($f['carrierCompany'] ?? '')],
        ['Адрес погрузки', (string) ($old['load_address'] ?? ''), (string) ($f['loadAddress'] ?? '')],
        ['Контакт погрузки', (string) ($old['load_contact'] ?? ''), (string) ($f['loadContact'] ?? '')],
        ['Дата погрузки с', (string) ($old['load_date_from'] ?? ''), (string) ($f['loadDateFrom'] ?? '')],
        ['Дата погрузки по', (string) ($old['load_date_to'] ?? ''), (string) ($f['loadDateTo'] ?? '')],
        ['Время погрузки', (string) ($old['load_time'] ?? ''), (string) ($f['loadTime'] ?? '')],
        ['Адрес выгрузки', (string) ($old['unload_address'] ?? ''), (string) ($f['unloadAddress'] ?? '')],
        ['Контакт выгрузки', (string) ($old['unload_contact'] ?? ''), (string) ($f['unloadContact'] ?? '')],
        ['Дата выгрузки с', (string) ($old['unload_date_from'] ?? ''), (string) ($f['unloadDateFrom'] ?? '')],
        ['Дата выгрузки по', (string) ($old['unload_date_to'] ?? ''), (string) ($f['unloadDateTo'] ?? '')],
        ['Время выгрузки', (string) ($old['unload_time'] ?? ''), (string) ($f['unloadTime'] ?? '')],
    ];
    foreach ($pairs as [$label, $was, $now]) {
        if ($was === $now) continue;
        if ($was === '') $was = '—';
        if ($now === '') $now = '—';
        crm_sys_comment($pdo, $appId, "{$label}: {$was} ➔ {$now}", 'crm_app_comments', 'app_id', 'ac_');
    }
}

/**
 * Обобщённая вставка комментария (#19): одна функция для лидов и перевозчиков.
 * $commentTable: 'crm_comments' | 'crm_carrier_comments' | 'crm_app_comments'
 * $attTable: 'crm_attachments' | 'crm_carrier_attachments' | 'crm_app_attachments'
 * $fkColumn: 'lead_id' | 'carrier_id' | 'app_id'
 * $prefix: 'c_' | 'cc_' | 'ac_' — префикс id комментария
 * Возвращает id созданного комментария.
 */
function crm_insert_comment(PDO $pdo, string $commentTable, string $attTable, string $fkColumn, string $fkId, string $text, array $user, array $atts, string $prefix = 'c_'): string {
    $cid = crm_new_id($pdo, $prefix, $commentTable);
    $pdo->prepare("INSERT INTO {$commentTable} (id, {$fkColumn}, text, author, user_id, time, edited_at) VALUES (?,?,?,?,?,?,NULL)")
        ->execute([$cid, $fkId, $text, $user['name'], (int) $user['id'], now_ms()]);
    if ($atts) {
        $insA = $pdo->prepare("INSERT INTO {$attTable} (comment_id, name, size, type, data_url) VALUES (?,?,?,?,?)");
        foreach ($atts as $a) $insA->execute([$cid, $a['name'], $a['size'], $a['type'], $a['dataUrl']]);
    }
    return $cid;
}

/**
 * Переименования стадий: не трогать лиды при обычной перестановке колонок.
 * Переименование определяется только если ровно один старый этап исчез и ровно один новый появился
 * (остальные — те же, возможно в другом порядке). Во всех остальных случаях (добавление, удаление,
 * массовая замена) — пустой список: лиды с неизвестным этапом ниже ловит UPDATE ... NOT IN.
 */
function crm_stage_renames(array $old, array $ns): array {
    $removed = array_diff($old, $ns);
    $added = array_diff($ns, $old);
    if (count($removed) === 1 && count($added) === 1) {
        return [[array_values($removed)[0], array_values($added)[0]]];
    }
    return [];
}

function crm_like_pat(string $s): string {
    $s = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
    return '%' . $s . '%';
}

/**
 * Запрос для MATCH...AGAINST (BOOLEAN MODE) из пользовательской строки: каждое слово
 * длиной от 3 символов (короче не попадают в FULLTEXT-индекс InnoDB при дефолтном
 * innodb_ft_min_token_size=3) становится обязательным префиксом («+слово*»).
 * Спецоператоры BOOLEAN MODE служат разделителями и в запрос не попадают.
 * Пустой результат — строка для FULLTEXT непригодна, ищем прежним LIKE.
 */
function crm_ft_query(string $q): string {
    $words = preg_split('/[\s+\-><()~*"@]+/u', $q, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $parts = [];
    foreach ($words as $w) {
        if (mb_strlen($w, 'UTF-8') < 3) continue;
        $parts[] = '+' . $w . '*';
    }
    return implode(' ', $parts);
}

/**
 * Поиск по корзине (§36): удалённые лиды всех менеджеров. Пустой запрос —
 * последние удалённые (просмотр корзины), иначе match по названию/ИНН.
 */
function crm_search_deleted(PDO $pdo, string $q): array {
    $q = trim($q);
    $digits = preg_replace('/\D/', '', $q) ?? '';
    $sel = 'SELECT l.id, l.title, l.inn, l.deleted_at, u.name AS owner, d.name AS deleted_by FROM crm_leads l INNER JOIN crm_users u ON u.id = l.user_id LEFT JOIN crm_users d ON d.id = l.deleted_by WHERE l.deleted_at <> 0';
    $params = [];
    if ($q !== '') {
        $sel .= ' AND (l.title LIKE ?';
        $params[] = crm_like_pat($q);
        if (strlen($digits) >= 2) {
            $sel .= ' OR l.inn LIKE ?';
            $params[] = crm_like_pat($digits);
        }
        $sel .= ')';
    }
    $st = $pdo->prepare($sel . ' ORDER BY l.deleted_at DESC LIMIT 40');
    $st->execute($params);
    $out = [];
    foreach ($st as $r) {
        $out[] = [
            'id' => (string) $r['id'],
            'title' => (string) $r['title'],
            'inn' => (string) $r['inn'],
            'owner' => (string) $r['owner'],
            'deletedBy' => (string) ($r['deleted_by'] ?? ''),
            'deletedAt' => (int) $r['deleted_at'],
        ];
    }
    return ['leads' => $out, 'intersections' => []];
}

function crm_search_leads(PDO $pdo, int $userId, string $q): array {
    $q = trim($q);
    if ($q === '') return ['leads' => [], 'intersections' => []];
    $digits = preg_replace('/\D/', '', $q);
    $titlePat = crm_like_pat($q);
    $ownSql = 'SELECT id, title, inn, stage, phone FROM crm_leads WHERE user_id = ? AND deleted_at = 0 AND (title LIKE ?';
    $ownParams = [$userId, $titlePat];
    // Свой поиск по ИНН — тоже от 4 цифр (раньше было 2): по двузначным фрагментам
    // перебирались все лиды с похожим ИНН, что при большом объёме замедляло поиск.
    if (strlen($digits) >= CRM_SEARCH_MIN_CHARS) {
        $ownSql .= ' OR inn LIKE ?';
        $ownParams[] = crm_like_pat($digits);
    }
    $ownSql .= ') ORDER BY title ASC LIMIT 40';
    $st = $pdo->prepare($ownSql);
    $st->execute($ownParams);
    $leads = [];
    foreach ($st as $r) {
        $leads[] = [
            'id' => $r['id'],
            'title' => $r['title'],
            'inn' => $r['inn'],
            'stage' => $r['stage'],
            'phone' => $r['phone'],
        ];
    }

    // «Пересечения» — чужие лиды с тем же клиентом. Показываем их только по достаточно точному
    // запросу (≥4 символа названия или ≥4 цифры ИНН) и не больше 20 за раз: по двузначным
    // фрагментам ИНН («77», «78», …) раньше можно было выгрузить всю клиентскую базу компании.
    //
    // Этот запрос — единственный, который ищет по ВСЕЙ таблице (ревью, п. 6.2), поэтому
    // с v16 он ходит по индексам: название — FULLTEXT (MATCH по началу слов), ИНН —
    // префиксный LIKE 'цифры%' по idx_inn (ИНН нормализован миграцией и при сохранении).
    // Если FULLTEXT-индекс на хостинге не создался (v16 это молча переживает) или запрос
    // для него непригоден (все слова короче 3 символов) — прежний LIKE '%...%'.
    $byTitle = mb_strlen($q, 'UTF-8') >= CRM_SEARCH_MIN_CHARS;
    $byInn = strlen($digits) >= CRM_SEARCH_MIN_CHARS;
    if (!$byTitle && !$byInn) return ['leads' => $leads, 'intersections' => []];
    $othSelect = 'SELECT l.title, l.inn, u.name AS owner FROM crm_leads l INNER JOIN crm_users u ON u.id = l.user_id WHERE l.user_id <> ? AND l.deleted_at = 0 AND (';
    $ftQuery = $byTitle ? crm_ft_query($q) : '';
    $st = null;
    if ($ftQuery !== '') {
        $conds = ['MATCH(l.title) AGAINST(? IN BOOLEAN MODE)'];
        $othParams = [$userId, $ftQuery];
        if ($byInn) { $conds[] = 'l.inn LIKE ?'; $othParams[] = $digits . '%'; /* только цифры, экранировать нечего */ }
        try {
            $st = $pdo->prepare($othSelect . implode(' OR ', $conds) . ') LIMIT 20');
            $st->execute($othParams);
        } catch (PDOException $e) {
            $st = null; // нет FULLTEXT-индекса (хостинг не дал создать) — fallback ниже
        }
    }
    if ($st === null) {
        $othParams = [$userId];
        $conds = [];
        if ($byTitle) { $conds[] = 'l.title LIKE ?'; $othParams[] = $titlePat; }
        if ($byInn) { $conds[] = 'l.inn LIKE ?'; $othParams[] = crm_like_pat($digits); }
        $st = $pdo->prepare($othSelect . implode(' OR ', $conds) . ') LIMIT 20');
        $st->execute($othParams);
    }
    $grouped = [];
    foreach ($st as $r) {
        $inn = preg_replace('/\D/', '', (string) $r['inn']);
        $key = $inn !== '' ? ('inn:' . $inn) : ('t:' . mb_strtolower((string) $r['title']));
        if (!isset($grouped[$key])) {
            $grouped[$key] = ['title' => $r['title'], 'inn' => $r['inn'], 'users' => []];
        }
        $name = (string) $r['owner'];
        if ($name !== '' && !in_array($name, $grouped[$key]['users'], true)) {
            $grouped[$key]['users'][] = $name;
        }
    }
    return ['leads' => $leads, 'intersections' => array_values($grouped)];
}

function crm_name_key(string $name): string {
    $name = trim($name);
    if (function_exists('mb_strtolower')) return mb_strtolower($name, 'UTF-8');
    return strtolower($name);
}

function crm_reserved_user_name(string $name): bool {
    $n = crm_name_key($name);
    return $n === 'система' || $n === 'system';
}

/**
 * Активность клиентов по месяцам: для каждого ИНН возвращает массив месяцев,
 * в которых была хотя бы одна поездка (заявка). Группирует все лиды с одинаковым ИНН.
 * Включает лиды без заявок (они отображаются с пустыми месяцами).
 * Возвращает: [ { inn, title, months: { 1: count, 3: count, ... } } ]
 */
function crm_client_activity(PDO $pdo, int $userId, int $year): array {
    // 1) Все клиенты (по ИНН) — включая тех, у кого нет заявок
    $stClients = $pdo->prepare("SELECT inn, MAX(title) AS title FROM crm_leads WHERE user_id = ? AND deleted_at = 0 AND inn <> '' GROUP BY inn ORDER BY inn");
    $stClients->execute([$userId]);
    $clients = [];
    foreach ($stClients->fetchAll() as $r) {
        $inn = (string) $r['inn'];
        $clients[$inn] = ['inn' => $inn, 'title' => $r['title'], 'months' => []];
    }
    if (!$clients) return [];
    // 2) Заявки за год — добавляем месяцы к существующим клиентам.
    // Год фильтруем диапазоном по created_at (миллисекунды), а не YEAR(FROM_UNIXTIME(...)):
    // функция от колонки не даёт использовать индекс и заставляла считать её для каждой строки.
    // Месяц считаем в PHP, а не MONTH(FROM_UNIXTIME(...)) в SQL: MySQL берёт свою time_zone,
    // и при расхождении с TZ PHP заявка у границы месяца попадала бы в соседний месяц
    // (а границы года и номера месяцев считались бы в разных зонах). Теперь обе величины —
    // границы года и номер месяца — считаются в одной и той же зоне PHP (date.timezone).
    $from = (new DateTimeImmutable("$year-01-01 00:00:00"))->getTimestamp() * 1000;
    $to = (new DateTimeImmutable(($year + 1) . "-01-01 00:00:00"))->getTimestamp() * 1000;
    $stTrips = $pdo->prepare("SELECT l.inn, a.created_at
            FROM crm_lead_apps a
            INNER JOIN crm_leads l ON l.id = a.lead_id
            WHERE l.user_id = ?
              AND a.created_at >= ? AND a.created_at < ?
              AND l.inn <> ''
              AND l.deleted_at = 0");
    $stTrips->execute([$userId, $from, $to]);
    foreach ($stTrips->fetchAll() as $r) {
        $inn = (string) $r['inn'];
        if (!isset($clients[$inn])) continue;
        $month = (int) date('n', intdiv((int) $r['created_at'], 1000));
        $clients[$inn]['months'][$month] = ($clients[$inn]['months'][$month] ?? 0) + 1;
    }
    return array_values($clients);
}

/**
 * Системный комментарий определяется по пересечению двух условий: user_id = 0 И author = 'Система'.
 * Только user_id = 0 — недостаточно: миграция v4 могла оставить user_id = 0 у старых пользовательских
 * комментариев, чей автор не нашёлся в crm_users. Только author — хрупко (ручная правка БД).
 * Пересечение исключает оба ложных срабатывания.
 */
function crm_is_sys_comment(array $c): bool {
    return (int) ($c['user_id'] ?? -1) === 0
        && trim((string) ($c['author'] ?? '')) === 'Система';
}
