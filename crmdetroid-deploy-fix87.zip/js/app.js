'use strict';
/* global $, $$, Modal, Net, Store, Theme, Toast, _confirmResolver:writable, _promptResolver:writable, activityShiftYear, askConfirm, askPrompt, addTagFromModal, autoGrowComposer, checkLeadDupDebounced, clearSearch, closeImageLightbox, closeLeadAppModal, closeLeadTagsModal, closeSearchDrop, confirmDeleteUser, debounce, deleteLeadApp, deleteTagFromModal, editingCommentAttCount, formatInnInput, formatMarginInput, goNeighborCarrier, goNeighborLead, initClientsEvents, initDashboardSearch, isValidEmail, leadAppsOf, liveSearch, loadActivity, loadApps, loadAppComments, loadClients, loadLeadComments, loadRoutes, loadUsers, openApp, openCarrier, openDeleteUser, openImageLightbox, openLead, openLeadAppModal, openLeadTagsModal, openRoute, passwordError, persistOk, pickTagColor, refreshAppLog, removeLeadAppCache, renderAppLog, renderAppStatus, renderBoard, renderCarrierLog, renderFiles, renderLog, resetBoardCache, saveAppDebounced, saveAppForm, saveCarrierDebounced, saveCarrierForm, saveLeadAppFromModal, saveLeadDebounced, saveLeadForm, setActivityUser, setAppsQuery, setAppsUser, syncLeadAppCache, updateAppSaveUI, updateCarrierSaveUI, updateLeadSaveUI, setRoutesFilter, setupPhoneMask, submitLeadTags, toggleTagInModal, withLock */
/* exported syncAdminNav, toggleUserMenu, updateSearchPlaceholder */

const UI = { leadId: null, routeId: null, carrierId: null, carrierRev: null, carrierCanManage: false, carrierComments: [], appId: null, appRev: null, appLeadId: null, appLeadTitle: '', appComments: [], pendingFiles: [], editFiles: [], drag: {}, currentView: 'kanban', formDirty: false, editingCommentId: null, lock: false, shellReady: false, appEvents: false };

function syncAdminNav(user) {
  // Разделы переехали с шапки на дашборд: для админа осталось только показать/спрятать плитку «Сотрудники»
  $('#tile-users')?.classList.toggle('hidden', user?.role !== 'admin');
}

function isReservedUserName(name) {
  const n = String(name || '').trim().toLowerCase();
  return n === 'система' || n === 'system';
}
function updateSearchPlaceholder() {
  const inp = $('#board-search'); if (!inp) return;
  inp.placeholder = Store.state.user?.role === 'admin'
    ? 'Поиск по названию, ИНН или сотруднику'
    : 'Поиск по названию или ИНН';
}

function toggleUserMenu() {
  const menu = $('#user-menu');
  const button = $('#user-display-name');
  if (!menu || !button) return;
  const open = menu.classList.toggle('hidden');
  button.setAttribute('aria-expanded', String(!open));
}

function updateViewBanner() {
  const b = $('#view-user-banner'); if (!b) return;
  b.classList.toggle('show', !!Store.viewUserId);
  const n = $('#view-user-name'); if (n) n.textContent = Store.viewUserName || '';
}

async function viewUserBoard(id, name) {
  // Пункты сотрудников в поиске рендерятся только админу, но прямой вызов из консоли
  // раньше молча показывал пустую доску (сервер отвечал 403) — гард (ревью, п. 2.5)
  if (Store.state.user?.role !== 'admin') return;
  id = parseInt(id, 10);
  closeSearchDrop();
  clearSearch();
  if (!id || id === Store.state.user?.id) {
    await exitViewUser();
    return;
  }
  Store.viewUserId = id;
  Store.viewUserName = name || '';
  Net.hash = null; Store.since = 0; resetBoardCache();
  updateViewBanner();
  navTo(currentRoute() || 'kanban', true);
  if (UI.currentView !== 'kanban') await goHome(true);
  else renderBoard();
  await Store.load(true);
}

async function exitViewUser() {
  const had = !!Store.viewUserId;
  Store.viewUserId = null; Store.viewUserName = '';
  Net.hash = null; Store.since = 0; resetBoardCache();
  updateViewBanner();
  navTo(currentRoute() || 'kanban', true);
  if (UI.currentView !== 'kanban') await goHome(true);
  if (had) await Store.load(true); else renderBoard();
}

function handleLogoutUI(msg) {
  stopPolling();
  UI.leadId = null; UI.routeId = null; UI.carrierId = null; UI.carrierComments = []; UI.appId = null; UI.appRev = null; UI.appLeadId = null; UI.appLeadTitle = ''; UI.appComments = []; UI.editingCommentId = null; UI.formDirty = false;
  Store.viewUserId = null; Store.viewUserName = '';
  Store.state.user = null; Store.state.leads = []; Store.state.stages = [];
  Net.hash = null; Store.since = 0; resetBoardCache();
  clearSearch();
  // Маршрут теперь в pathname — на форме входа сбрасываем URL в корень
  // (search и битый путь тоже: ?as=… чужой доски не должен переживать разлогин)
  history.replaceState(null, '', '/');
  $$('.view-section').forEach(el => el.classList.remove('active'));
  const kv = $('#kanban-view'); if (kv) kv.classList.add('active');
  document.body.classList.remove('booting');
  document.body.classList.add('guest');
  $('#login-overlay').classList.add('show');
  if (msg && msg !== 'Сессия истекла') Toast.error(msg);
  // Токен для входа не запрашиваем заранее: он одноразовый и живёт 15 минут,
  // поэтому его берёт сам execLogin() непосредственно перед отправкой формы.
  Net.csrf = null;
}

function readAsParam() {
  return parseInt(new URLSearchParams(location.search).get('as') || '0', 10) || 0;
}
/**
 * Красивые ссылки без # (History API): маршрут — это путь от корня («/kanban», «/lead/<id>»).
 * navTo принимает и старую форму «#lead/…» — ведущая решётка просто отбрасывается,
 * чтобы не переписывать все вызовы одномоментно и не ломать чужие закладки.
 */
function routePath(route) {
  route = String(route || '').replace(/^#/, '');
  if (route && route[0] !== '/') route = '/' + route;
  const as = Store.viewUserId;
  const q = as ? ('?as=' + encodeURIComponent(as)) : '';
  return (route || '/kanban') + q;
}
function navTo(route, push = true) {
  const url = routePath(route);
  const now = location.pathname + location.search;
  if (now === url) return;
  if (push) history.pushState(null, '', url);
  else history.replaceState(null, '', url);
}
/** Текущий маршрут: путь без ведущего слэша; старые ссылки с #маршрутом на любом пути тоже понимаем. */
function currentRoute() {
  const h = location.hash.replace(/^#/, '');
  // Закладка старого формата (#lead/abc) — маршрут берём из hash и молча переписываем URL на новый вид.
  // Якоря как в .htaccess: #kanbanfoo — не маршрут, а обычный якорь, его не трогаем.
  if (h && /^((kanban|dashboard|routes|activity|apps|clients|users)$|(lead|carrier|route|app)\/[^/]+$)/.test(h)) {
    history.replaceState(null, '', routePath(h));
    return h;
  }
  return location.pathname.replace(/^\//, '');
}
async function syncViewUserFromUrl() {
  if (!Store.state.user || Store.state.user.role !== 'admin') {
    if (Store.viewUserId) {
      Store.viewUserId = null;
      Store.viewUserName = '';
      updateViewBanner();
    }
    return false;
  }
  const as = readAsParam();
  const cur = Store.viewUserId ? +Store.viewUserId : 0;
  if (as === cur) {
    if (as) {
      const col = (Store.state.colleagues || []).find(u => +u.id === as);
      if (col) Store.viewUserName = col.name;
      updateViewBanner();
    }
    return false;
  }
  if (as && as !== +Store.state.user.id) {
    Store.viewUserId = as;
    const col = (Store.state.colleagues || []).find(u => +u.id === as);
    Store.viewUserName = col?.name || 'Сотрудник';
  } else {
    Store.viewUserId = null;
    Store.viewUserName = '';
  }
  Net.hash = null; Store.since = 0;
  resetBoardCache();
  updateViewBanner();
  await Store.load(true);
  return true;
}

/* === НАВИГАЦИЯ (РОУТЕР) === */
// decodeURIComponent бросает URIError на битом пути (lead/%E0) — тогда просто идём на доску.
function routeParam(route, prefix) {
  try { return decodeURIComponent(route.slice(prefix.length)); } catch (e) { return ''; }
}
function handleHashRouting() {
  const route = currentRoute();
  if (route.startsWith('lead/')) {
    const targetLeadId = routeParam(route, 'lead/');
    // Без проверки Store.getLead: удалённого нет в сторе до ensureLeadFull-транзита (§35),
    // и deep-link в корзину уходил на доску (ревью §37, F2). openLead сам разберётся.
    if (targetLeadId) { openLead(targetLeadId, false); return; }
  } else if (route.startsWith('carrier/')) {
    const cid = routeParam(route, 'carrier/');
    if (cid) { openCarrier(cid, false); return; }
  } else if (route.startsWith('route/')) {
    const rid = routeParam(route, 'route/');
    if (rid) { openRoute(rid, false); return; }
  } else if (route.startsWith('app/')) {
    const aid = routeParam(route, 'app/');
    if (aid) { openApp(aid, false); return; }
  } else if (route === 'dashboard') {
    switchView('dashboard-view', false); return;
  } else if (route === 'routes') {
    switchView('routes-view', false); return;
  } else if (route === 'activity') {
    switchView('activity-view', false); return;
  } else if (route === 'apps') {
    switchView('apps-view', false); return;
  } else if (route === 'clients') {
    switchView('clients-view', false); return;
  } else if (route === 'users' && Store.state.user?.role === 'admin') {
    switchView('users-view', false); return;
  }
  switchView('kanban-view', false);
}

// При нажатии кнопок Назад/Вперед в браузере
window.addEventListener('popstate', async () => {
  if (!Store.state.user) return;
  await syncViewUserFromUrl();
  handleHashRouting();
});

async function switchView(viewId, updateHash = true) {
  if (UI.leadId && UI.formDirty) {
    const saved = await saveLeadForm(true);
    if (!persistOk(saved)) return;
    if (saved?.transferred) await Store.load(true);
  }
  if (UI.carrierId && UI.formDirty) {
    const savedC = await saveCarrierForm(true);
    if (!persistOk(savedC)) return;
  }
  if (UI.appId && UI.formDirty) {
    const savedA = await saveAppForm(true);
    if (!persistOk(savedA)) return;
  }
  UI.leadId = null; UI.routeId = null; UI.carrierId = null; UI.carrierComments = []; UI.appId = null; UI.appRev = null; UI.appLeadId = null; UI.appLeadTitle = ''; UI.appComments = []; UI.pendingFiles = []; UI.formDirty = false; UI.editingCommentId = null;
  UI.currentView = viewId.replace('-view', '');

  $$('.view-section').forEach(el => el.classList.remove('active'));
  // Разделы в шапке убраны (переехали на дашборд) — подсвечиваем только кнопку дашборда,
  // иначе она «залипала» активной при переходе в другие разделы
  $('#nav-dashboard')?.classList.remove('active');
  const viewEl = $('#'+viewId); if (viewEl) viewEl.classList.add('active');

  if (viewId === 'dashboard-view') {
    $('#nav-dashboard')?.classList.add('active');
    if (updateHash) navTo('dashboard');
  } else if (viewId === 'kanban-view') {
    if (updateHash) navTo('kanban');
    updateViewBanner();
    renderBoard();
  } else if (viewId === 'users-view') {
    if (updateHash) navTo('users');
    loadUsers();
  } else if (viewId === 'routes-view') {
    if (updateHash) navTo('routes');
    loadRoutes();
  } else if (viewId === 'activity-view') {
    if (updateHash) navTo('activity');
    loadActivity();
  } else if (viewId === 'apps-view') {
    if (updateHash) navTo('apps');
    loadApps();
  } else if (viewId === 'clients-view') {
    if (updateHash) navTo('clients');
    loadClients();
  }
}

function goHome(updateHash = true) { return switchView('kanban-view', updateHash); }

async function execLogout() {
  if (UI.formDirty && !await askConfirm('Есть несохранённые изменения', 'Выйти без сохранения?', 'primary')) return;
  UI.formDirty = false;
  await Net.req('logout', {}); location.reload();
}

function initEvents() {
  $('#btn-login').addEventListener('click', execLogin);
  $('#login-password').addEventListener('keydown', e => { if (e.key === 'Enter') execLogin(); });
  $('#login-email').addEventListener('keydown', e => { if (e.key === 'Enter') $('#login-password').focus(); });
}

/**
 * Оркестратор подписок на события приложения. Сами обработчики разнесены по
 * тематическим функциям ниже — раньше всё лежало одной простынёй в 600 строк.
 */
function initAppEvents() {
  if (UI.appEvents) return;
  UI.appEvents = true;
  initViewControlEvents();
  initAutosaveEvents();
  initLeadTransferEvents();
  initComposerEvents();
  initActionDispatch();
  initBoardClick();
  initClientsEvents();
  initKeyboardShortcuts();
  initDashboardSearch();
  initDragDrop();
}

/** Маски телефонов/ИНН, живой поиск, стрелки соседних карточек, фильтры «Активности» и «Заявок». */
function initViewControlEvents() {
  setupPhoneMask($('#m-phone')); setupPhoneMask($('#f-logist-phone'));
  $('#m-inn').addEventListener('input', e => { formatInnInput(e.target); checkLeadDupDebounced(); });
  $('#f-inn').addEventListener('input', e => formatInnInput(e.target));

  const searchInp = $('#board-search');
  const runSearch = debounce(() => liveSearch(searchInp.value), 150);
  searchInp.addEventListener('input', runSearch);
  searchInp.addEventListener('focus', () => { if (searchInp.value.trim()) liveSearch(searchInp.value); });
  searchInp.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const first = $('#search-drop .search-item[data-action]');
      if (first) first.click();
    } else if (e.key === 'Escape' && (searchInp.value || $('#search-drop.open'))) {
      e.preventDefault(); e.stopPropagation();
      clearSearch();
    }
  });
  $('#board-search-clear').addEventListener('click', () => { clearSearch(); searchInp.focus(); });
  const routesSearch = $('#routes-search');
  const runRoutesSearch = debounce(() => { setRoutesFilter(routesSearch.value.trim()); loadRoutes(); }, 200);
  routesSearch.addEventListener('input', runRoutesSearch);
  setupPhoneMask($('#k-phone'));
  $('#cf-inn')?.addEventListener('input', e => formatInnInput(e.target));
  $('#k-inn')?.addEventListener('input', e => formatInnInput(e.target));
  document.addEventListener('click', e => {
    if (!e.target.closest('#board-search-wrap') && !e.target.closest('#search-drop')) closeSearchDrop();
    if (!e.target.closest('#user-menu-wrap')) {
      const menu = $('#user-menu');
      if (menu && !menu.classList.contains('hidden')) {
        menu.classList.add('hidden');
        $('#user-display-name')?.setAttribute('aria-expanded', 'false');
      }
    }
  });

  $('#btn-prev-lead').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); goNeighborLead(-1); });
  $('#btn-next-lead').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); goNeighborLead(1); });
  $('#btn-prev-carrier').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); goNeighborCarrier(-1); });
  $('#btn-next-carrier').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); goNeighborCarrier(1); });
  $('#activity-prev-year')?.addEventListener('click', () => activityShiftYear(-1));
  $('#activity-next-year')?.addEventListener('click', () => activityShiftYear(1));
  $('#activity-employee')?.addEventListener('change', async (e) => {
    setActivityUser(parseInt(e.target.value, 10));
    loadActivity();
  });
  $('#apps-employee')?.addEventListener('change', (e) => {
    setAppsUser(parseInt(e.target.value, 10));
    loadApps();
  });
  $('#apps-search')?.addEventListener('input', debounce((e) => {
    setAppsQuery(e.target.value.trim());
    loadApps();
  }, 350));
}

/** Автосохранение форм лида, перевозчика и заявки: input-грязь, debounce и страховка beforeunload. */
function initAutosaveEvents() {
  window.addEventListener('beforeunload', e => {
    if (!UI.formDirty) return;
    if (UI.appId) saveAppForm(false, true); else if (UI.carrierId) saveCarrierForm(false, true); else saveLeadForm(false, true);
    e.preventDefault();
    e.returnValue = '';
  });
  $('#detail-view').addEventListener('input', e => { if (e.target.matches('.form-input, .editable-title')) { UI.formDirty = true; updateLeadSaveUI('dirty'); saveLeadDebounced(); } });
  $('#la-inn')?.addEventListener('input', e => formatInnInput(e.target));
  $('#la-rate')?.addEventListener('input', e => formatMarginInput(e.target));
  $('#la-margin')?.addEventListener('input', e => formatMarginInput(e.target));
  $('#la-carrier-rate')?.addEventListener('input', e => formatMarginInput(e.target));
  $('#carrier-view').addEventListener('input', e => { if (e.target.matches('.form-input, .editable-title') && UI.carrierCanManage) { UI.formDirty = true; updateCarrierSaveUI('dirty'); saveCarrierDebounced(); } });
  $('#app-view').addEventListener('input', e => { if (e.target.matches('.form-input, .editable-title')) { UI.formDirty = true; updateAppSaveUI('dirty'); saveAppDebounced(); } });
  $('#ap-inn')?.addEventListener('input', e => formatInnInput(e.target));
  $('#ap-rate')?.addEventListener('input', e => formatMarginInput(e.target));
  $('#ap-margin')?.addEventListener('input', e => formatMarginInput(e.target));
  $('#ap-carrier-rate')?.addEventListener('input', e => formatMarginInput(e.target));
}

/** Передача лида другому продавцу через поле «Продавец». */
function initLeadTransferEvents() {
  /*
   * Передача лида через поле «Продавец»: срабатывает СРАЗУ при вводе полного имени коллеги
   * (вручную или выбором из подсказки), а не только при уходе из поля. Пауза 400 мс после
   * последней буквы — чтобы окно не выскакивало посреди набора, если имя одного сотрудника
   * начинается с имени другого. Передача — только при полном совпадении имени (без регистра):
   * одна фамилия не переводит лид («Иванов» могло уйти не тому Иванову).
   * _transferPrompting — защита от двойного окна: при открытии подтверждения фокус уходит
   * из поля, и blur-обработчик (страховка для «ввёл и сразу кликнул мимо») сработал бы вторым.
   */
  let _transferPrompting = false;
  async function promptManagerTransfer() {
    if (_transferPrompting || !UI.leadId) return false;
    const lead = Store.getLead(UI.leadId);
    const typed = ($('#f-manager').value || '').trim();
    const prev = (lead && lead.manager) || '';
    if (!typed || typed === prev || !Store.state.colleagues) return false;
    const q = typed.toLowerCase().replace(/\s+/g, ' ');
    const hits = Store.state.colleagues.filter(u => String(u.name || '').toLowerCase().replace(/\s+/g, ' ') === q);
    const ownerId = Store.viewUserId || (Store.state.user && Store.state.user.id);
    if (!(hits.length === 1 && +hits[0].id !== +ownerId)) return false;
    _transferPrompting = true;
    try {
      saveLeadDebounced.cancel();
      if (!await askConfirm('Вы точно хотите передать карточку?', 'Лид уйдёт сотруднику «' + hits[0].name + '» вместе с логом и файлами')) {
        $('#f-manager').value = prev;
        // Остальные правки формы (если были) сохраняем штатно — уже со старым продавцом
        if (UI.formDirty) await saveLeadForm(true);
        return true; // обработано: пользователь отказался, имя возвращено
      }
      saveLeadDebounced.cancel();
      const res = await saveLeadForm(true, false, +hits[0].id);
      if (res && res.transferred) { await Store.load(true); await goHome(true); }
      return true;
    } finally {
      _transferPrompting = false;
    }
  }
  const promptManagerTransferDebounced = debounce(() => promptManagerTransfer(), 400);
  $('#f-manager').addEventListener('input', promptManagerTransferDebounced);
  $('#f-manager').addEventListener('blur', async () => {
    if (!UI.leadId || _transferPrompting) return;
    promptManagerTransferDebounced.cancel();
    saveLeadDebounced.cancel();
    // Страховка: имя введено и фокус ушёл раньше, чем сработала пауза 400 мс
    const handled = await promptManagerTransfer();
    if (!handled) await saveLeadForm(true);
  });
}

/** Composer комментариев: Enter-отправка, авторост поля, выбор/вставка/валидация вложений. */
function initComposerEvents() {
  // Enter в поле нового тега — создать тег (а не «ничего»)
  $('#tag-new-name')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addTagFromModal(); } });
  $('#comment-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('[data-action="post-comment"]').click(); } });
  $('#carrier-comment-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('[data-action="post-carrier-comment"]').click(); } });
  $('#app-comment-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('[data-action="post-app-comment"]').click(); } });
  // Composer в духе Odoo: поле растёт под текст (autoGrowComposer в util.js)
  $('#comment-input').addEventListener('input', e => autoGrowComposer(e.target));
  $('#carrier-comment-input').addEventListener('input', e => autoGrowComposer(e.target));
  $('#app-comment-input').addEventListener('input', e => autoGrowComposer(e.target));
  const bindLogEnter = el => el.addEventListener('keydown', e => { if (e.target.matches('.inline-editor textarea') && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $(`[data-action="save-comment"][data-cid="${e.target.dataset.inp}"]`).click(); } });
  bindLogEnter($('#chatter-log'));
  bindLogEnter($('#carrier-chatter-log'));
  bindLogEnter($('#app-chatter-log'));

  const allowExt = new Set(['png','jpg','jpeg','gif','webp','bmp','pdf','txt','csv','doc','docx','xls','xlsx','ppt','pptx','zip','7z']);
  const mimeExt = { 'image/png':'png', 'image/jpeg':'jpg', 'image/jpg':'jpg', 'image/gif':'gif', 'image/webp':'webp', 'image/bmp':'bmp' };
  function fileExtOf(f) {
    const fromName = ((f.name || '').split('.').pop() || '').toLowerCase();
    if (fromName && fromName !== (f.name || '').toLowerCase()) return fromName;
    return mimeExt[(f.type || '').toLowerCase()] || fromName;
  }
  function addPendingFiles(list) {
    const editing = !!UI.editingCommentId;
    const bucket = editing ? (UI.editFiles || (UI.editFiles = [])) : UI.pendingFiles;
    const used = (editing ? editingCommentAttCount() : 0) + bucket.length;
    if (used >= 8) return Toast.error('Максимум 8 файлов');
    [...list].forEach(f => {
      if (!f) return;
      if ((editing ? editingCommentAttCount() : 0) + bucket.length >= 8) return;
      if (f.size > 5 * 1024 * 1024) return Toast.error(`Файл "${f.name || 'скриншот'}" > 5МБ`);
      let ext = fileExtOf(f);
      let name = f.name || '';
      if (!name || name === 'image.png' || name === 'image.jpg') {
        ext = ext || 'png';
        name = 'screenshot-' + new Date().toISOString().slice(0,19).replace(/[:T]/g, '-') + '.' + ext;
      }
      if (!allowExt.has(ext) || /\.(php|phtml|phar|cgi|exe|js|htm|html|svg|shtml)(\.|$)/i.test(name)) {
        return Toast.error(`Файл "${name}" не разрешён`);
      }
      const file = (name !== f.name) ? new File([f], name, { type: f.type || ('image/' + (ext === 'jpg' ? 'jpeg' : ext)) }) : f;
      bucket.push({ name: file.name, size: file.size, type: file.type, rawFile: file });
    });
    renderFiles();
  }
  const onPickFiles = e => {
    addPendingFiles(e.target.files || []);
    e.target.value = '';
  };
  $('#file-input').addEventListener('change', onPickFiles);
  $('#carrier-file-input').addEventListener('change', onPickFiles);
  $('#app-file-input').addEventListener('change', onPickFiles);
  document.addEventListener('change', e => {
    if (e.target && e.target.classList && e.target.classList.contains('edit-file-input')) onPickFiles(e);
  });
  document.addEventListener('paste', e => {
    if (UI.currentView !== 'lead' && UI.currentView !== 'carrier' && UI.currentView !== 'app') return;
    if ($('.modal-backdrop.open')) return;
    const tag = ((e.target && e.target.tagName) || '').toUpperCase();
    if (tag === 'INPUT') return;
    const dt = e.clipboardData;
    if (!dt) return;
    const files = [];
    if (dt.files && dt.files.length) files.push(...dt.files);
    else if (dt.items) {
      [...dt.items].forEach(it => {
        if (it.kind === 'file') {
          const f = it.getAsFile();
          if (f) files.push(f);
        }
      });
    }
    const imgs = files.filter(f => /^image\//i.test(f.type || '') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(f.name || ''));
    if (!imgs.length) return;
    e.preventDefault();
    addPendingFiles(imgs);
  });
}

/** Главный делегат кликов по data-action: навигация, модалки, CRUD-действия. */
function initActionDispatch() {
  document.body.addEventListener('click', async e => {
    const actEl = e.target.closest('[data-action]'); if (!actEl) return;
    const act = actEl.dataset.action;
    // Плитки дашборда — <a href="/маршрут"> ради фокуса и Enter с клавиатуры; сам переход
    // делает switchView (ниже), а браузерный дефолт гасим, иначе будет полная перезагрузка.
    // Только для go-* навигации: ссылки вложений (open-image) обрабатываются своей веткой.
    if (actEl.tagName === 'A' && act.startsWith('go-')) e.preventDefault();

    if (act === 'prompt-cancel') {
      const r = _promptResolver; _promptResolver = null;
      Modal.closeAll(); if (r) r(null);
      return;
    }
    if (act === 'confirm-cancel') {
      const r = _confirmResolver; _confirmResolver = null;
      Modal.close('modal-confirm'); if (r) r(false);
      return;
    }
    if (act === 'close-modals') {
      if ($('#modal-lead-app.open')) { await closeLeadAppModal(); return; }
      if ($('#modal-tags.open')) { await closeLeadTagsModal(); return; }
      Modal.closeAll();
      return;
    }
    if (act === 'close-lightbox') { closeImageLightbox(); return; }
    if (act === 'open-image') {
      e.preventDefault();
      openImageLightbox(actEl.dataset.src || actEl.getAttribute('href') || '');
      return;
    }

    await withLock(() => dispatchAction(act, actEl))();
  });
}

/**
 * Разводит data-action по тематическим обработчикам: первый распознавший — выполняет.
 * Обработчик возвращает false ТОЛЬКО из default-ветки («не моё действие»); любые другие
 * значения — включая undefined от ранних `return;` при провале валидации — значат
 * «действие распознано», и дальше по цепочке оно не идёт.
 */
async function dispatchAction(act, actEl) {
  if (await handleNavAction(act, actEl) !== false) return;
  if (await handleDirectoryAction(act, actEl) !== false) return;
  if (await handleSessionAction(act) !== false) return;
  if (await handleCreateAction(act, actEl) !== false) return;
  if (await handleAdminAction(act, actEl) !== false) return;
  if (await handleLeadCardAction(act, actEl) !== false) return;
  await handleChatterAction(act, actEl);
}

/** Навигация: живой поиск, доски сотрудников, соседние карточки, разделы, маршруты. */
async function handleNavAction(act, actEl) {
  switch (act) {
      case 'open-search-lead':
        if (actEl.dataset.id) { closeSearchDrop(); await openLead(actEl.dataset.id, true); }
        break;
      case 'view-user-board':
        await viewUserBoard(actEl.dataset.id, actEl.dataset.name);
        break;
      case 'exit-view-user':
        await exitViewUser();
        break;
      case 'prev-lead': goNeighborLead(-1); break;
      case 'next-lead': goNeighborLead(1); break;
      case 'prev-carrier': goNeighborCarrier(-1); break;
      case 'next-carrier': goNeighborCarrier(1); break;
      case 'go-home': goHome(true); break;
      case 'go-dashboard': switchView('dashboard-view', true); break;
      case 'go-kanban': switchView('kanban-view', true); break;
      case 'go-clients': switchView('clients-view', true); break;
      case 'go-routes': switchView('routes-view', true); break;
      case 'go-users': if (Store.state.user?.role === 'admin') switchView('users-view', true); break;
      case 'go-activity': switchView('activity-view', true); break;
      case 'go-apps': switchView('apps-view', true); break;
      case 'open-app-lead': {
        const lid = actEl.dataset.id; if (!lid) break;
        // Лид чужого сотрудника (админ смотрит реестр через as) в Store отсутствует —
        // openLead молча ушёл бы на доску; вместо этого объясняем, как посмотреть.
        if (Store.getLead(lid)) await openLead(lid, true);
        else Toast.error('Лид другого сотрудника — откройте его доску через «Сотрудники»');
        break;
      }
      case 'open-app': {
        const aid = actEl.dataset.id; if (!aid) break;
        // Как open-app-lead: заявка чужого сотрудника (админ смотрит чужой реестр)
        // в get_app не пройдёт — объясняем сразу, а не молча уходим на доску.
        const lid = actEl.dataset.leadid;
        if (lid && !Store.getLead(lid)) { Toast.error('Заявка другого сотрудника — откройте его доску через «Сотрудники»'); break; }
        await openApp(aid, true);
        break;
      }
      case 'back-app': {
        if (UI.appId && UI.formDirty) {
          const savedB = await saveAppForm(true);
          if (!persistOk(savedB)) return;
        }
        if (UI.appLeadId) await openLead(UI.appLeadId, true); else goHome(true);
        break;
      }
      case 'open-activity-client': {
        const inn = actEl.dataset.inn;
        if (!inn) break;
        await switchView('kanban-view', true);
        const searchInp = $('#board-search');
        if (searchInp) { searchInp.value = inn; liveSearch(inn); }
        break;
      }
      case 'open-route': if (actEl.dataset.id) openRoute(actEl.dataset.id, true); break;
      default: return false;
  }
  return true;
}

/** Справочник перевозчиков: направления, карточка перевозчика и его лог. */
async function handleDirectoryAction(act, actEl) {
  switch (act) {
      case 'new-direction':
        $('#d-from').value = ''; $('#d-to').value = '';
        Modal.open('modal-direction'); setTimeout(() => $('#d-from').focus(), 50);
        break;
      case 'submit-direction': {
        const from = $('#d-from').value.trim(), to = $('#d-to').value.trim();
        if (!from || !to) return Toast.error('Укажите оба города');
        const resD = await Net.req('save_direction', { cityFrom: from, cityTo: to });
        if (resD?.success) { Modal.closeAll(); await loadRoutes(); openRoute(resD.id, true); }
        else Toast.error(resD?.error || 'Ошибка');
        break;
      }
      case 'delete-direction': {
        if (!UI.routeId) return;
        if (!await askConfirm('Удалить направление?', 'Все перевозчики на нём тоже удалятся')) return;
        const resDD = await Net.req('delete_direction', { id: UI.routeId });
        if (resDD?.success) { UI.routeId = null; switchView('routes-view', true); }
        else Toast.error(resDD?.error || 'Ошибка');
        break;
      }

      case 'new-carrier':
        if (!UI.routeId) return;
        $('#k-name').value = ''; $('#k-phone').value = ''; $('#k-company').value = ''; $('#k-inn').value = '';
        Modal.open('modal-carrier'); setTimeout(() => $('#k-name').focus(), 50);
        break;
      case 'submit-carrier': {
        const name = $('#k-name').value.trim();
        if (!name) return Toast.error('Укажите имя или название');
        const payload = { directionId: UI.routeId, name, phone: $('#k-phone').value.trim(), company: $('#k-company').value.trim(), inn: $('#k-inn').value.replace(/\D/g, '') };
        const resK = await Net.req('save_carrier', payload);
        if (resK?.success) { Modal.closeAll(); await openCarrier(resK.id, true); }
        else Toast.error(resK?.error || 'Ошибка');
        break;
      }
      case 'open-carrier':
        if (actEl.dataset.id) openCarrier(actEl.dataset.id, true);
        break;
      case 'back-carrier':
        if (UI.carrierId && UI.formDirty) {
          const savedB = await saveCarrierForm(true);
          if (!persistOk(savedB)) return;
        }
        if (UI.routeId) openRoute(UI.routeId, true); else switchView('routes-view', true);
        break;
      case 'delete-carrier': {
        const delId = actEl.dataset.id || UI.carrierId;
        if (!delId) return;
        if (!await askConfirm('Удалить перевозчика?', 'Лог тоже удалится')) return;
        const resDK = await Net.req('delete_carrier', { id: delId });
        if (resDK?.success) {
          UI.carrierId = null;
          if (UI.routeId) await openRoute(UI.routeId, true); else switchView('routes-view', true);
        } else Toast.error(resDK?.error || 'Ошибка');
        break;
      }
      case 'post-carrier-comment': {
        const txt = $('#carrier-comment-input').value.trim(); if (!txt && !UI.pendingFiles.length) return;
        if (!UI.carrierId) return;
        const fd = new FormData(); fd.append('carrier_id', UI.carrierId); fd.append('text', txt);
        UI.pendingFiles.forEach(f => fd.append('files[]', f.rawFile));
        const resPCC = await Net.req('add_carrier_comment', fd, true);
        if (resPCC?.success) { $('#carrier-comment-input').value = ''; autoGrowComposer($('#carrier-comment-input')); UI.pendingFiles = []; await openCarrier(UI.carrierId, false); }
        else Toast.error(resPCC?.error || 'Ошибка');
        break;
      }
      default: return false;
  }
  return true;
}

let _pwSelfService = false; // true — добровольная смена из шапки (не must_change)
/** Сеанс и оформление: тема, смена пароля, выход. */
async function handleSessionAction(act) {
  switch (act) {
      case 'toggle-theme': Theme.toggle(); break;
      case 'toggle-user-menu': toggleUserMenu(); break;
      case 'submit-password': {
        const np = $('#pw-new')?.value || '', n2 = $('#pw-new2')?.value || '';
        const npErr = passwordError(np); if (npErr) return Toast.error(npErr);
        if (np !== n2) return Toast.error('Пароли не совпадают');
        const resPw = await Net.req('change_password', { password: np, old: $('#pw-old')?.value || '' });
        if (resPw?.success) {
          Modal.closeAll();
          if ($('#pw-old')) $('#pw-old').value = '';
          if ($('#pw-new')) $('#pw-new').value = '';
          if ($('#pw-new2')) $('#pw-new2').value = '';
          Toast.success('Пароль обновлён');
          // must_change догружает приложение; добровольная смена — только тост (ревью §37, G10)
          if (!_pwSelfService) { await Store.load(true); handleHashRouting(); startPolling(); }
        } else Toast.error(resPw?.error || 'Ошибка');
        break;
      }
      case 'change-password':
        $('#user-menu')?.classList.add('hidden');
        $('#user-display-name')?.setAttribute('aria-expanded', 'false');
        openPasswordModal(true);
        break;
      case 'close-password-modal': Modal.close('modal-password'); break;
      case 'logout':
        $('#user-menu')?.classList.add('hidden');
        $('#user-display-name')?.setAttribute('aria-expanded', 'false');
        execLogout();
        break;
      // Баннер «Вышло обновление»: билд на сервере новее загруженного.
      case 'reload-app': location.reload(); break;
      case 'dismiss-update-banner': $('#update-banner')?.classList.add('hidden'); break;
      default: return false;
  }
  return true;
}

/** Создание сущностей: заявки лида, новый лид. */
async function handleCreateAction(act, actEl) {
  switch (act) {
      case 'new-lead-app':
        if (!UI.leadId) return;
        openLeadAppModal(null);
        break;
      case 'edit-lead-app': {
        const app = leadAppsOf(Store.getLead(UI.leadId)).find(a => String(a.id) === String(actEl.dataset.id || ''));
        if (!app) return;
        openLeadAppModal(app);
        break;
      }
      case 'delete-lead-app':
        await deleteLeadApp(actEl.dataset.id);
        break;
      case 'submit-lead-app':
        await saveLeadAppFromModal();
        break;
      case 'new-lead': {
        $$('#modal-create input').forEach(i => i.value = '');
        const dupWarn = $('#m-inn-warn'); if (dupWarn) { dupWarn.classList.add('hidden'); dupWarn.textContent = ''; }
        Modal.open('modal-create'); setTimeout(() => $('#m-title').focus(), 50); break;
      }
      case 'open-add-user': $$('#modal-add-user input').forEach(i => { if (i.type === 'checkbox') i.checked = false; else i.value = ''; }); Modal.open('modal-add-user'); setTimeout(() => $('#u-name').focus(), 50); break;

      case 'submit-lead': {
        const t = $('#m-title').value.trim(), i = $('#m-inn').value.trim(), em = $('#m-email').value.trim();
        if (!t) return Toast.error('Введите название');
        if (i && i.length !== 10 && i.length !== 12) return Toast.error('ИНН 10 или 12 цифр');
        if (!isValidEmail(em)) return Toast.error('Некорректный email');
        // id новому лиду выдаёт сервер
        // Телефон из окна создания сразу попадает и в «Контакт логиста» (logistPhone):
        // карточка лида и доска показывают именно его. В phone тоже сохраняем — как раньше.
        const mPhone = $('#m-phone').value.trim();
        const resL = await Net.req('save_lead', {
          title: t, inn: i, phone: mPhone, email: em,
          ati: ($('#m-ati')?.value || '').trim(),
          logistName: ($('#m-logist-name')?.value || '').trim(),
          logistPhone: mPhone,
          stage: Store.state.stages[0]
        });
        if (resL?.success) { Modal.closeAll(); await Store.load(true); } else Toast.error(resL?.error || 'Ошибка');
        break;
      }
      default: return false;
  }
  return true;
}

/** Администрирование: сотрудники и этапы воронки. */
async function handleAdminAction(act, actEl) {
  switch (act) {
      case 'submit-user': {
        const n = $('#u-name').value.trim(), ue = $('#u-email').value.trim(), p = $('#u-pass').value;
        if (!n || !ue || !p) return Toast.error('Все поля');
        if (isReservedUserName(n)) return Toast.error('Это имя зарезервировано');
        if (!isValidEmail(ue)) return Toast.error('Некорректный email');
        const pErr = passwordError(p); if (pErr) return Toast.error(pErr);
        const resU = await Net.req('register_user', { name: n, email: ue, password: p, role: $('#u-admin')?.checked ? 'admin' : 'user' });
        if (resU?.success) { Toast.success('Добавлен'); Modal.closeAll(); loadUsers(); } else Toast.error(resU?.error || 'Ошибка');
        break;
      }

      case 'save-user': {
        const id = actEl.dataset.id, un = $(`#uname-${id}`).value.trim(), uem = $(`#uemail-${id}`).value.trim(), up = $(`#upass-${id}`).value, ur = $(`#urole-${id}`)?.value || 'user';
        if (!un || !uem) return Toast.error('Обязательны Имя и Email');
        if (isReservedUserName(un)) return Toast.error('Это имя зарезервировано');
        if (!isValidEmail(uem)) return Toast.error('Некорректный email');
        if (up) { const upErr = passwordError(up); if (upErr) return Toast.error(upErr); }
        // Пароль отправляем только если поле трогали руками: автозаполнение браузера могло
        // подставить пароль админа в чужую строку, а «💾» тихо сменил бы сотруднику пароль.
        const passEl = $(`#upass-${id}`);
        const payloadU = { id: +id, name: un, email: uem, role: ur };
        if (up && passEl?.dataset.typed === '1') payloadU.password = up;
        const resS = await Net.req('update_user', payloadU);
        if (resS?.success) { Toast.success('Сохранено'); loadUsers(); } else Toast.error(resS?.error || 'Ошибка');
        break;
      }

      case 'delete-user':
        openDeleteUser(+actEl.dataset.id);
        break;

      case 'confirm-delete-user':
        await confirmDeleteUser();
        break;

      case 'add-stage': {
        const stN = await askPrompt('Новый этап', '', 'Название этапа'); if (!stN || !stN.trim()) return;
        const resSt = await Net.req('save_stages', { stages: [...Store.state.stages, stN.trim()] });
        if (resSt?.success) await Store.load(true); else Toast.error(resSt?.error || 'Ошибка');
        break;
      }

      case 'edit-stage': {
        const oldSt = actEl.closest('.column').dataset.stage, newSt = await askPrompt('Изменить этап', oldSt, 'Пустое = удалить');
        if (newSt === null || newSt.trim() === oldSt) return;
        let ns = [...Store.state.stages];
        if (!newSt.trim()) {
          if (ns.length <= 1) return Toast.error('Нельзя удалить последний');
          const left = ns.filter(s => s !== oldSt);
          const nLeads = Store.state.leads.filter(l => l.stage === oldSt).length;
          const dest = left[0] || '';
          const msg = nLeads
            ? `${nLeads} лид(ов) будут перенесены в «${dest}». Отменить это будет нельзя.`
            : 'Этап пустой.';
          if (!await askConfirm('Удалить этап «' + oldSt + '»?', msg)) return;
          ns = left;
        } else {
          if (ns.includes(newSt.trim())) return Toast.error('Имя занято');
          ns[ns.indexOf(oldSt)] = newSt.trim();
        }
        const resESt = await Net.req('save_stages', { stages: ns });
        if (resESt?.success) await Store.load(true); else Toast.error(resESt?.error || 'Ошибка');
        break;
      }
      default: return false;
  }
  return true;
}

/** Карточка лида/перевозчика/заявки: сохранение, теги, удаление, смена этапа. */
async function handleLeadCardAction(act, actEl) {
  switch (act) {
      case 'save-lead-now': {
        if (!UI.leadId) return;
        // Немедленное сохранение без ожидания debounce (кнопка активна только при formDirty)
        saveLeadDebounced.cancel();
        await saveLeadForm(true);
        break;
      }

      // --- Теги лида (v17) ---
      case 'open-lead-tags': openLeadTagsModal(); break;
      case 'toggle-tag': toggleTagInModal(actEl.dataset.id); break;
      case 'pick-tag-color': pickTagColor(actEl.dataset.color); break;
      case 'add-tag': await addTagFromModal(); break;
      case 'del-tag': await deleteTagFromModal(actEl.dataset.id); break;
      case 'submit-lead-tags': await submitLeadTags(); break;

      case 'save-carrier-now': {
        if (!UI.carrierId) return;
        saveCarrierDebounced.cancel();
        await saveCarrierForm(true);
        break;
      }

      case 'save-app-now': {
        if (!UI.appId) return;
        saveAppDebounced.cancel();
        await saveAppForm(true);
        break;
      }

      case 'delete-lead': {
        if (!await askConfirm('Удалить лид?', 'Лид переместится в удалённые — его можно будет восстановить')) return;
        const delLead = Store.getLead(UI.leadId);
        const delRev = delLead ? (delLead._editRev ?? delLead.updatedAt) : 0;
        const resDL = await Net.req('delete_lead', { id: UI.leadId, updatedAt: delRev });
        if (resDL?.success) { goHome(true); await Store.load(true); }
        else if (resDL?.error === 'Карточка изменена в другом месте') { Toast.error('Карточку изменили в другой вкладке — обновляю'); await Store.load(true); }
        else Toast.error(resDL?.error || 'Ошибка');
        break;
      }

      case 'take-lead': {
        if (!UI.leadId) return;
        const res = await Net.req('restore_lead', { id: UI.leadId });
        if (!res?.success) { Toast.error(res?.error || 'Не удалось взять в работу'); return; }
        Store.state.leads = Store.state.leads.filter(l => l.id !== UI.leadId);
        await Store.load(true);
        await openLead(UI.leadId, true);
        break;
      }

      case 'purge-lead': {
        if (!UI.leadId) return;
        if (!await askConfirm('Удалить навсегда?', 'Лид, заявки, лог и файлы будут стёрты без возможности восстановления')) return;
        const res = await Net.req('purge_lead', { id: UI.leadId });
        if (!res?.success) { Toast.error(res?.error || 'Не удалось удалить'); return; }
        Store.state.leads = Store.state.leads.filter(l => l.id !== UI.leadId);
        goHome(true); await Store.load(true);
        break;
      }

      case 'delete-app': {
        if (!UI.appId) return;
        if (!await askConfirm('Удалить заявку?', 'Лог заявки тоже удалится')) return;
        saveAppDebounced.cancel();
        UI.formDirty = false;
        const resDA = await Net.req('delete_lead_app', { id: UI.appId, updatedAt: UI.appRev });
        if (resDA?.success) {
          removeLeadAppCache(UI.appLeadId, UI.appId, resDA);
          const backLead = UI.appLeadId;
          UI.appId = null;
          if (backLead) await openLead(backLead, true); else goHome(true);
          await Store.load(true);
        }
        else if (resDA?.error === 'Заявка изменена в другом месте') {
          Toast.error('Заявку изменили в другой вкладке — обновляю');
          if (UI.appId) await openApp(UI.appId, false);
        }
        else Toast.error(resDA?.error || 'Ошибка');
        break;
      }

      case 'set-stage': {
        const lead = Store.getLead(UI.leadId); if (!lead) return;
        // Как в switchView: невалидная форма блокирует и смену этапа (ревью, п. 2.3)
        if (UI.formDirty) {
          const savedSt = await saveLeadForm(true);
          if (!persistOk(savedSt)) return;
        }
        const resMS = await Net.req('move_lead', { id: UI.leadId, stage: actEl.dataset.stage, updatedAt: lead._editRev ?? lead.updatedAt });
        if (resMS?.success) await Store.load(true);
        else if (resMS?.error === 'Карточка изменена в другом месте') { Toast.error('Карточку изменили в другой вкладке — обновляю'); await Store.load(true); }
        else Toast.error(resMS?.error || 'Ошибка');
        break;
      }

      case 'set-app-status': {
        if (!UI.appId) return;
        // Как set-stage: грязная форма сначала сохраняется — иначе ревизия
        // для смены статуса устареет и сервер ответит конфликтом.
        if (UI.formDirty) {
          const savedStA = await saveAppForm(true);
          if (!persistOk(savedStA)) return;
        }
        const resAS = await Net.req('set_app_status', { id: UI.appId, status: actEl.dataset.status, updatedAt: UI.appRev });
        if (resAS?.success && resAS.application) {
          UI.appRev = resAS.application.updatedAt;
          syncLeadAppCache(UI.appLeadId, resAS);
          renderAppStatus(resAS.application.status);
          // Смена статуса пишет системную запись — подтягиваем лог сразу.
          await refreshAppLog();
        }
        else if (resAS?.error === 'Заявка изменена в другом месте') {
          Toast.error('Заявку изменили в другой вкладке — обновляю');
          UI.formDirty = false;
          if (UI.appId) await openApp(UI.appId, false);
        }
        else Toast.error(resAS?.error || 'Ошибка');
        break;
      }
      default: return false;
  }
  return true;
}

/** Лог (chatter): комментарии, их правка и вложения. */
async function handleChatterAction(act, actEl) {
  switch (act) {
      case 'post-comment': {
        const txt = $('#comment-input').value.trim(); if (!txt && !UI.pendingFiles.length) return;
        const fd = new FormData(); fd.append('lead_id', UI.leadId); fd.append('text', txt);
        UI.pendingFiles.forEach(f => fd.append('files[]', f.rawFile));
        const resPC = await Net.req('add_comment', fd, true);
        if (resPC?.success) {
          const L = Store.getLead(UI.leadId);
          if (L && resPC.updatedAt) { L.updatedAt = resPC.updatedAt; L._editRev = resPC.updatedAt; }
          $('#comment-input').value = ''; autoGrowComposer($('#comment-input')); UI.pendingFiles = []; renderFiles(); await Store.load(true); await loadLeadComments(UI.leadId); renderLog();
        } else Toast.error(resPC?.error || 'Ошибка');
        break;
      }

      case 'post-app-comment': {
        const txt = $('#app-comment-input').value.trim(); if (!txt && !UI.pendingFiles.length) return;
        if (!UI.appId) return;
        const fd = new FormData(); fd.append('app_id', UI.appId); fd.append('text', txt);
        UI.pendingFiles.forEach(f => fd.append('files[]', f.rawFile));
        const resPA = await Net.req('add_app_comment', fd, true);
        if (resPA?.success) {
          // Комментарий трогает ревизию заявки (touch_app) — обновляем, иначе
          // следующее сохранение грязной формы ложно конфликтнёт.
          if (resPA.updatedAt) UI.appRev = resPA.updatedAt;
          $('#app-comment-input').value = ''; autoGrowComposer($('#app-comment-input')); UI.pendingFiles = []; renderFiles();
          await loadAppComments(UI.appId); renderAppLog();
        } else Toast.error(resPA?.error || 'Ошибка');
        break;
      }

      case 'rm-file': (UI.editingCommentId ? UI.editFiles : UI.pendingFiles).splice(+actEl.dataset.idx, 1); renderFiles(); break;

      case 'toggle-edit': {
        const cid = actEl.dataset.cid;
        const edt = $(`[data-edt="${cid}"]`), txtEl = $(`[data-txt="${cid}"]`), inp = $(`[data-inp="${cid}"]`);
        if (!edt) return; const active = edt.classList.contains('active');
        $$('.inline-editor.active').forEach(e => e.classList.remove('active')); $$('.log-text.hidden').forEach(e => e.classList.remove('hidden'));
        UI.editFiles = [];
        if (!active) { txtEl.classList.add('hidden'); edt.classList.add('active'); UI.editingCommentId = cid; inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); renderFiles(); }
        else { UI.editingCommentId = null; renderFiles(); }
        break;
      }

      case 'save-comment': {
        const v = $(`[data-inp="${actEl.dataset.cid}"]`).value.trim();
        const extra = UI.editFiles || [];
        if (!v && !extra.length && !editingCommentAttCount()) return Toast.error('Пусто');
        const isCarrier = UI.currentView === 'carrier', isApp = UI.currentView === 'app';
        const fd = new FormData();
        fd.append('id', actEl.dataset.cid);
        fd.append('text', v);
        extra.forEach(f => fd.append('files[]', f.rawFile));
        const resSC = await Net.req(isCarrier ? 'edit_carrier_comment' : isApp ? 'edit_app_comment' : 'edit_comment', fd, true);
        if (resSC?.success) {
          UI.editingCommentId = null;
          UI.editFiles = [];
          if (isCarrier) {
            if (resSC.updatedAt) UI.carrierRev = resSC.updatedAt;
            await openCarrier(UI.carrierId, false);
          } else if (isApp) {
            // Как лид, а не перевозчик: обновляем только лог — форма заявки
            // не перечитывается и несохранённый ввод цел.
            if (resSC.updatedAt) UI.appRev = resSC.updatedAt;
            if (UI.appId) { await loadAppComments(UI.appId); renderAppLog(); }
          } else {
            const L = Store.getLead(UI.leadId);
            if (L && resSC.updatedAt) { L.updatedAt = resSC.updatedAt; L._editRev = resSC.updatedAt; }
            await Store.load(true);
            if (UI.leadId) { await loadLeadComments(UI.leadId); renderLog(); }
          }
        } else Toast.error(resSC?.error || 'Ошибка');
        break;
      }

      case 'del-att': {
        if (!await askConfirm('Удалить вложение?')) return;
        const attId = String(actEl.dataset.id || '');
        if (!attId) return;
        // kind обязателен: номера вложений лидов, перевозчиков и заявок независимы и могут совпадать
        const resDA = await Net.req('delete_attachment', { id: +attId, kind: UI.currentView === 'carrier' ? 'carrier' : UI.currentView === 'app' ? 'app' : 'lead' });
        if (!resDA?.success) { Toast.error(resDA?.error || 'Ошибка'); break; }
        const dropAtt = list => (list || []).map(c => Object.assign({}, c, {
          attachments: (c.attachments || []).filter(a => String(a.id) !== attId)
        }));
        if (UI.currentView === 'carrier') {
          if (resDA.updatedAt) UI.carrierRev = resDA.updatedAt;
          UI.carrierComments = dropAtt(UI.carrierComments);
          renderCarrierLog();
        } else if (UI.currentView === 'app') {
          if (resDA.updatedAt) UI.appRev = resDA.updatedAt;
          UI.appComments = dropAtt(UI.appComments);
          renderAppLog();
        } else {
          const L = Store.getLead(UI.leadId);
          if (L) {
            if (resDA.updatedAt) { L.updatedAt = resDA.updatedAt; L._editRev = resDA.updatedAt; }
            if (Array.isArray(L.comments)) L.comments = dropAtt(L.comments);
          }
          renderLog();
        }
        break;
      }

      case 'del-comment': {
        if (!await askConfirm('Удалить комментарий?')) return;
        const isCarrier = UI.currentView === 'carrier', isApp = UI.currentView === 'app';
        const delId = String(actEl.dataset.cid || '');
        const resDC = await Net.req(isCarrier ? 'delete_carrier_comment' : isApp ? 'delete_app_comment' : 'delete_comment', { id: delId });
        if (resDC?.success) {
          UI.editingCommentId = null;
          if (isCarrier) {
            if (resDC.updatedAt) UI.carrierRev = resDC.updatedAt;
            UI.carrierComments = (UI.carrierComments || []).filter(c => String(c.id) !== delId);
            renderCarrierLog();
            await openCarrier(UI.carrierId, false);
          } else if (isApp) {
            if (resDC.updatedAt) UI.appRev = resDC.updatedAt;
            UI.appComments = (UI.appComments || []).filter(c => String(c.id) !== delId);
            renderAppLog();
            if (UI.appId) { await loadAppComments(UI.appId); renderAppLog(); }
          } else {
            const L = Store.getLead(UI.leadId);
            if (L) {
              if (resDC.updatedAt) { L.updatedAt = resDC.updatedAt; L._editRev = resDC.updatedAt; }
              if (Array.isArray(L.comments)) L.comments = L.comments.filter(c => String(c.id) !== delId);
            }
            renderLog();
            await Store.load(true);
            if (UI.leadId) { await loadLeadComments(UI.leadId); renderLog(); }
          }
        } else Toast.error(resDC?.error || 'Ошибка');
        break;
      }
  }
}

/** Клик по канбан-карточке открывает лид (кроме кликов по кнопкам колонок и сразу после drag). */
function initBoardClick() {
  $('#board').addEventListener('click', e => {
    if (e.target.closest('.col-edit') || e.target.closest('.add-column')) return;
    if (Date.now() < (UI.dragSuppressUntil || 0)) return;
    const card = e.target.closest('.card'); if (card) openLead(card.dataset.id, true);
  });
}

/** Глобальные клавиатурные сокращения (#16: вынесено из initAppEvents). */
function initKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    // Ctrl+S / Cmd+S на карточке лида, перевозчика или заявки — немедленное сохранение
    // (вместо «Сохранить страницу» браузера)
    if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S' || e.key === 'ы' || e.key === 'Ы')) {
      if (UI.currentView === 'lead' && UI.leadId) {
        e.preventDefault();
        if (UI.formDirty) { saveLeadDebounced.cancel(); saveLeadForm(true); }
        return;
      }
      if (UI.currentView === 'carrier' && UI.carrierId) {
        e.preventDefault();
        if (UI.formDirty) { saveCarrierDebounced.cancel(); saveCarrierForm(true); }
        return;
      }
      if (UI.currentView === 'app' && UI.appId) {
        e.preventDefault();
        if (UI.formDirty) { saveAppDebounced.cancel(); saveAppForm(true); }
        return;
      }
    }
    if (e.key === 'Enter' && $('#modal-lead-app.open') && !$('#modal-confirm.open') && !$('#modal-prompt.open') && !$('#modal-password.open')) {
      const tag = (document.activeElement && document.activeElement.tagName) || '';
      if (tag !== 'TEXTAREA' && document.activeElement && document.activeElement.closest('#modal-lead-app')) {
        e.preventDefault();
        // Как в диспетчере кликов — под глобальным withLock: иначе очередь Enter'ов
        // при висящем сохранении плодит дубли новой заявки (ревью v19, п. 1).
        withLock(() => saveLeadAppFromModal())();
        return;
      }
    }
    if ((UI.currentView === 'lead' || UI.currentView === 'carrier') && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
      const tag = (document.activeElement && document.activeElement.tagName) || '';
      // Не листаем соседние карточки, пока открыто модальное окно (например, «Теги лида»):
      // стрелки при фокусе вне input переключали бы лид под модалкой.
      if (!$('.modal-backdrop.open') && !/^(INPUT|TEXTAREA|SELECT)$/.test(tag) && !e.altKey && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (UI.currentView === 'carrier') goNeighborCarrier(e.key === 'ArrowLeft' ? -1 : 1);
        else goNeighborLead(e.key === 'ArrowLeft' ? -1 : 1);
        return;
      }
    }
    if (e.key === 'Escape') {
      if ($('#img-lightbox.open')) { closeImageLightbox(); return; }
      if ($('.inline-editor.active')) { $$('.inline-editor.active').forEach(el=>el.classList.remove('active')); $$('.log-text.hidden').forEach(el=>el.classList.remove('hidden')); UI.editingCommentId = null; UI.editFiles = []; renderFiles(); }
      else if ($('.modal-backdrop.open')) {
        if ($('#modal-password.open')) return;
        if ($('#modal-confirm.open')) {
          const cr = _confirmResolver; _confirmResolver = null;
          Modal.close('modal-confirm'); if (cr) cr(false); return;
        }
        if ($('#modal-lead-app.open')) { closeLeadAppModal(); return; }
        if ($('#modal-tags.open')) { closeLeadTagsModal(); return; }
        const pr = _promptResolver; _promptResolver = null;
        const cr = _confirmResolver; _confirmResolver = null;
        if (pr) pr(null); if (cr) cr(false); Modal.closeAll();
      }
    }
  });
}

/** Drag-n-drop для карточек и колонок канбан-доски (#16: вынесено из initAppEvents). */
function initDragDrop() {
  const b = $('#board');
  b.addEventListener('dragstart', e => {
    const card = e.target.closest('.card'), col = e.target.closest('.column');
    if (card) { UI.drag = { t: 'card', id: card.dataset.id }; card.classList.add('dragging'); e.dataTransfer.setData('text/plain', card.dataset.id); e.stopPropagation(); }
    else if (col) { UI.drag = { t: 'col', s: col.dataset.stage }; col.classList.add('dragging'); e.dataTransfer.setData('text/plain', col.dataset.stage); }
  });
  b.addEventListener('dragend', () => {
    $$('.dragging, .drop-target').forEach(el => el.classList.remove('dragging', 'drop-target'));
    UI.dragSuppressUntil = Date.now() + 400;
    UI.drag = {};
  });
  b.addEventListener('dragover', e => { if (UI.drag.t && e.target.closest('.column')) e.preventDefault(); });
  b.addEventListener('dragenter', e => { const c = e.target.closest('.column'); if (c && UI.drag.t) c.classList.add('drop-target'); });
  b.addEventListener('dragleave', e => { const c = e.target.closest('.column'); if (c && !c.contains(e.relatedTarget)) c.classList.remove('drop-target'); });
  b.addEventListener('drop', withLock(async e => {
    const c = e.target.closest('.column'); if (!c) return; e.preventDefault(); const tgt = c.dataset.stage;
    if (UI.drag.t === 'card') {
      const lead = Store.getLead(UI.drag.id); if (!lead || lead.stage === tgt) return;
      const res = await Net.req('move_lead', { id: UI.drag.id, stage: tgt, updatedAt: lead.updatedAt });
      if (res?.success) Store.load(true);
      else { Toast.error(res?.error || 'Не удалось переместить'); Store.load(true); }
    } else if (UI.drag.t === 'col') {
      const ns = [...Store.state.stages], f = ns.indexOf(UI.drag.s), t = ns.indexOf(tgt);
      if (f >= 0 && t >= 0 && f !== t) { ns.splice(t, 0, ns.splice(f, 1)[0]); const res = await Net.req('save_stages', { stages: ns }); if (res?.success) Store.load(true); }
    }
  }));
}

let pollTimer = null, pollDelay = 15000, unchangedStreak = 0, authBeat = null;
function startPolling() {
  stopPolling();
  const tick = async () => {
    if (!document.hidden && !UI.drag.t && !UI.formDirty && !$('.modal-backdrop.open') && !$('.inline-editor.active')) {
      const before = Net.hash;
      await Store.load(false);
      if (Net.hash && Net.hash === before) {
        unchangedStreak++;
        pollDelay = unchangedStreak >= 3 ? 30000 : 15000;
      } else {
        unchangedStreak = 0;
        pollDelay = 15000;
      }
    }
    pollTimer = setTimeout(tick, pollDelay);
  };
  pollTimer = setTimeout(tick, pollDelay);
  authBeat = setInterval(async () => {
    if (document.hidden || !Store.state.user) return;
    await Net.req('check_auth');
  }, 4 * 60 * 1000);
}
function stopPolling() {
  if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
  if (authBeat) { clearInterval(authBeat); authBeat = null; }
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && Store.state.user) Store.load(false); });

async function loadAppShell() {
  if (UI.shellReady) {
    document.body.classList.remove('guest');
    return true;
  }
  try {
    const opts = { method: 'GET', headers: {}, keepalive: true };
    if (Net.csrf) opts.headers['X-CSRF-Token'] = Net.csrf;
    const res = await fetch('/api.php?action=ui', opts);
    const ctype = (res.headers.get('content-type') || '');
    if (!res.ok || ctype.includes('application/json')) {
      handleLogoutUI();
      return false;
    }
    const html = await res.text();
    // Defense-in-depth: ui.html не должен содержать inline-скриптов (CSP и так их блокирует,
    // но если заголовок потеряется — это второй слой). При обнаружении — отказываемся грузить shell.
    if (/<script\b/i.test(html)) {
      console.error('CRM: ui.html содержит <script> — shell не загружен');
      handleLogoutUI('Ошибка загрузки интерфейса');
      return false;
    }
    const root = $('#app-root');
    if (!root) return false;
    root.innerHTML = html;
    UI.shellReady = true;
    document.body.classList.remove('guest');
    $('#login-overlay').classList.remove('show');
    initAppEvents();
    return true;
  } catch (e) {
    Net.setOnline(false);
    return false;
  }
}

function revealApp() {
  document.body.classList.remove('booting', 'guest');
  $('#login-overlay')?.classList.remove('show');
}

function revealLogin() {
  document.body.classList.remove('booting');
  document.body.classList.add('guest');
  $('#login-overlay')?.classList.add('show');
}

function openPasswordModal(self) {
  _pwSelfService = !!self;
  $('#pw-title').textContent = self ? 'Смена пароля' : 'Смените пароль';
  $('#pw-message').textContent = self ? 'Введите текущий пароль и новый (не короче 8 символов).' : 'Сейчас стоит временный пароль из инструкции. Задайте свой — не короче 8 символов.';
  $('#pw-old-field').classList.toggle('hidden', !self);
  $('#pw-cancel').classList.toggle('hidden', !self);
  ['pw-old', 'pw-new', 'pw-new2'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  Modal.open('modal-password');
  setTimeout(() => $('#pw-new')?.focus(), 50);
}
function showMustChangePassword() {
  const box = $('#modal-password');
  if (!box) return;
  openPasswordModal(false);
}

async function afterLogin(mustChange, user) {
  if (!await loadAppShell()) { revealLogin(); return; }
  revealApp();
  if (mustChange) {
    showMustChangePassword();
    return;
  }
  const as = readAsParam();
  const role = user?.role || Store.state.user?.role;
  const uid = +(user?.id || Store.state.user?.id || 0);
  if (role === 'admin' && as && as !== uid) Store.viewUserId = as;
  await Store.load(true);
  await syncViewUserFromUrl();
  handleHashRouting();
  startPolling();
}

async function bootApp() {
  const check = await Net.req('check_auth');
  if (check?.success) {
    Net.csrf = check.csrf;
    await afterLogin(!!check.mustChangePassword, check.user);
  } else {
    // Ответ с need_login уже показал форму входа через handleLogoutUI; токен для входа
    // берём лениво в execLogin() — один запрос csrf на одну попытку, а не два на загрузку.
    revealLogin();
    setTimeout(() => $('#login-email')?.focus(), 50);
  }
}

async function fetchLoginCsrf() {
  const tok = await Net.req('csrf');
  if (tok && tok.csrf) { Net.csrf = tok.csrf; return null; }
  return (tok && tok.error) || 'Сервер недоступен, попробуйте ещё раз';
}

async function execLogin() {
  const email = $('#login-email').value.trim(), password = $('#login-password').value;
  $('#login-err').textContent = '';
  if (!email || !password) { $('#login-err').textContent = 'Заполните поля'; return; }
  $('#btn-login').disabled = true;
  // Одноразовый login-токен: свежий на каждую попытку входа.
  const tokErr = await fetchLoginCsrf();
  let res = tokErr ? { success: false, error: tokErr } : await Net.req('login', { email, password });
  if (res?.error === 'CSRF' && !(await fetchLoginCsrf())) {
    res = await Net.req('login', { email, password });
  }
  $('#btn-login').disabled = false;
  if (res && res.success) {
    Net.csrf = res.csrf;
    $('#login-password').value = '';
    await afterLogin(!!res.mustChangePassword, res.user);
  } else {
    $('#login-err').textContent = res?.error || 'Ошибка входа';
  }
}

Theme.apply(Theme.get());
initEvents();
bootApp();
